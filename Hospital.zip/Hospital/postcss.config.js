module.exports = {
  plugins: {
    autoprefixer: {}
  }
}
