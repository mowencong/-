<template>
    <div>
        <div class="header">
          <img src="../../../assets/img/logo.png" alt="">
          <div class="detail">
              <div class="countDown">
                  <van-circle
                      v-model="currentRate"
                      :rate="rate"
                      :speed="100"
                      :text="text"
                      :stroke-width="60"
                      color="#5D5D5D"
                  />
              </div>
              <div class="info">
                  <div class="tui">
                      <div class="name">赵敏</div>
                  </div>
                  <div class="time">
                      {{time}}
                  </div>
              </div>
          </div>
      </div>

        <top :title="title" :isHome='isHome'></top>

        <div class="content">
            <div class="item">
                <div class="title">姓名：</div>
                <div class="text">黄明政</div>
            </div>
            <div class="item">
                <div class="title">证件号码：</div>
                <div class="text">呼吸内科</div>
            </div>
            <div class="item">
                <div class="title">地址：</div>
                <div class="text">马晓玲</div>
            </div>
            <div class="btn">
                <div>下一步</div>
            </div>
        </div>
    </div>
</template>

<script>
import head from '../../../components/head'
export default {
    data(){
        return{
            title:'请将居民健康卡放置读卡区',
            isHome:false,
            currentRate: 0,
            currentTime:0,
            rate:0,
            total:120,
            timer:null,
            timer2:null,
            time:''
        }
    },
    computed: {
        text() {
            return this.currentTime.toFixed(0) + 's'
        }
    },
    components:{
        'top':head
    },
    created(){
        this.getDate();
        this.getTime();
    },
    mounted(){
        this.set();
    },
    methods:{
        go(){
            this.$router.push('/registrationInformation');
        },
        set(){
            let total = this.total;
            let that = this;
            let timer = setInterval(function(){
                let currentRate = that.currentRate;
                let currentTime = that.currentTime;
                currentTime++;
                currentRate = currentTime / total * 100;
                currentRate = parseInt(currentRate);
                that.currentTime = currentTime;
                that.currentRate = currentRate;
                if(total==currentTime){
                    clearInterval(timer);
                    that.$router.push('/index');
                    return;
                }
            },1000)
            this.timer = timer;
        },
        getDate(){
            let myDate = new Date();
            let year = myDate.getFullYear();
            let month = myDate.getMonth() + 1;
            let date = myDate.getDate();
            let hour = myDate.getHours();
            let minute = myDate.getMinutes();
            let second = myDate.getSeconds();
            if(month<10){
                month = '0' + month;
            }
            if(date<10){
                date = '0' + date;
            }
            if(hour<10){
                hour = '0' + hour;
            }
            if(minute<10){
                minute = '0' + minute;
            }
            if(second<10){
                second = '0' + second;
            }
            let str = `${year}年${month}月${date}日 ${hour}:${minute}:${second}`;
            this.time = str;
        },
        // 获取当前时间
        getTime(){
            let timer2 = setInterval(()=>{
                this.getDate();
            },1000)
            this.timer2 = timer2;
        },
    },
    beforeDestroy(){
        clearInterval(this.timer);
        clearInterval(this.timer2);
    }
}
</script>

<style scoped>
.van-circle >>> .van-circle__text{
    font-family: PingFangSC-Regular;
    font-size: 24px;
    color: #5D5D5D;
}
.content{
    background: #EBF6F5;
    height: 529.41px;
    margin: 0 auto;
    width: 1109.76px;
    margin-top: 33px;
    border: 1px solid transparent;
    display: flex;
    flex-direction: column;
    position: relative;
}
.item{
    display: flex;
    margin-left: 30px;
    margin-top: 50px;
}
.item .title{
    opacity: 0.5;
    font-family: PingFangSC-Regular;
    font-size: 24px;
    color: #5E5E5E;
    width: 150px;
    text-align: right;
}
.item .text{
    font-family: PingFangSC-Semibold;
    font-size: 26px;
    color: #5E5E5E;
    font-weight: bold;
}
.item .price{
    font-family: PingFangSC-Semibold;
    font-size: 26px;
    color: #DA251C;
    font-weight: bold;
}
.btn{
    width: 194.56px;
    height: 58.37px;
    display: flex;
    align-items: center;
    justify-content: center;
    background: #3FC7C5;
    border-radius: 8px;
    font-family: PingFangSC-Regular;
    font-size: 26px;
    color: #FFFFFF;
    position: absolute;
    bottom: 100px;
    left: 60px;
}
</style>