<template>
    <div>
        <div class="header">
            <img src="../../../assets/img/logo.png" alt="">

            <div class="detail">
                <div class="countDown">
                    <van-circle
                        v-model="currentRate"
                        :rate="rate"
                        :speed="100"
                        :text="text"
                        :stroke-width="60"
                        color="#5D5D5D"
                    />
                </div>
                <div class="info">
                    <div class="tui">
                        <!-- <div class="name">赵敏</div> -->
                    </div>
                    <div class="time">
                        {{time}}
                    </div>
                </div>
            </div>
        </div>
        
        <top :title="title" :isHome='isHome'></top>

        <div class="content">
            
            <div class="calc">
                <div class="inp">
                    <el-input v-model="input" placeholder="请输入电子健康码"></el-input>
                </div>
                <div class="key">
                    <table cellpadding="0" cellspacing="0">
                        <tr>
                            <td>
                                <van-button type="default" @click="ent(7)">7</van-button>
                            </td>
                            <td>
                                <van-button type="default" @click="ent(8)">8</van-button>
                            </td>
                            <td>
                                <van-button type="default" @click="ent(9)">9</van-button>
                            </td>
                        </tr>
                        <tr>
                            <td>
                                <van-button type="default" @click="ent(4)">4</van-button>
                            </td>
                            <td>
                                <van-button type="default" @click="ent(5)">5</van-button>
                            </td>
                            <td>
                                <van-button type="default" @click="ent(6)">6</van-button>
                            </td>
                        </tr>
                        <tr>
                            <td>
                                <van-button type="default" @click="ent(1)">1</van-button>
                            </td>
                            <td>
                                <van-button type="default" @click="ent(2)">2</van-button>
                            </td>
                            <td>
                                <van-button type="default" @click="ent(3)">3</van-button>
                            </td>
                        </tr>
                        <tr>
                            <td>
                                <van-button type="default">&nbsp;</van-button>
                            </td>
                            <td>
                                <van-button type="default" @click="ent(0)">0</van-button>
                            </td>
                            <td>
                                <van-button type="default" @click="tui">3</van-button>
                            </td>
                        </tr>
                    </table>
                </div>
            </div>

            <div class="btn">
                <div>下一步</div>
            </div>
        </div>
    </div>
</template>

<script>
import head from '../../../components/head'
export default {
    data(){
        return{
            title:'请讲身份证放置读卡区',
            isHome:false,
            currentRate: 0,
            currentTime:0,
            rate:0,
            total:120,
            timer:null,
            timer2:null,
            time:'',
            input:'',
        }
    },
    computed: {
        text() {
            return this.currentTime.toFixed(0) + 's'
        }
    },
    components:{
        'top':head
    },
    created(){
        this.getDate();
        this.getTime();
    },
    mounted(){
        this.set();
    },
    methods:{
        go(){
            this.$router.push('/registrationInformation');
        },
        set(){
            let total = this.total;
            let that = this;
            let timer = setInterval(function(){
                let currentRate = that.currentRate;
                let currentTime = that.currentTime;
                currentTime++;
                currentRate = currentTime / total * 100;
                currentRate = parseInt(currentRate);
                that.currentTime = currentTime;
                that.currentRate = currentRate;
                if(total==currentTime){
                    clearInterval(timer);
                    that.$router.push('/index');
                    return;
                }
            },1000)
            this.timer = timer;
        },
        getDate(){
            let myDate = new Date();
            let year = myDate.getFullYear();
            let month = myDate.getMonth() + 1;
            let date = myDate.getDate();
            let hour = myDate.getHours();
            let minute = myDate.getMinutes();
            let second = myDate.getSeconds();
            if(month<10){
                month = '0' + month;
            }
            if(date<10){
                date = '0' + date;
            }
            if(hour<10){
                hour = '0' + hour;
            }
            if(minute<10){
                minute = '0' + minute;
            }
            if(second<10){
                second = '0' + second;
            }
            let str = `${year}年${month}月${date}日 ${hour}:${minute}:${second}`;
            this.time = str;
        },
        // 获取当前时间
        getTime(){
            let timer2 = setInterval(()=>{
                this.getDate();
            },1000)
            this.timer2 = timer2;
        },
        // 输入
        ent(index){
            this.input += index;
        },
        // 退格
        tui(){
            let arr = this.input;
            arr = arr.split('');
            let len = arr.length-1;
            arr.splice(len,1);
            arr = arr.join('');
            this.input = arr;
        },
    },
    beforeDestroy(){
        clearInterval(this.timer);
        clearInterval(this.timer2);
    }
}
</script>

<style scoped>
.van-circle >>> .van-circle__text{
    font-family: PingFangSC-Regular;
    font-size: 24px;
    color: #5D5D5D;
}
.content{
    background: #EBF6F5;
    height: 529.41px;
    margin: 0 auto;
    width: 1109.76px;
    margin-top: 33px;
    border: 1px solid transparent;
    display: flex;
    flex-direction: column;
    position: relative;
    justify-content: center;
}

.btn{
    width: 194.56px;
    height: 58.37px;
    display: flex;
    align-items: center;
    justify-content: center;
    background: #3FC7C5;
    border-radius: 8px;
    font-family: PingFangSC-Regular;
    font-size: 26px;
    color: #FFFFFF;
    position: absolute;
    bottom: 100px;
    right: 60px;
}
.calc{
    width: 340px;
    /* height: 330px; */
    background: #fff;
    border: 1px solid #D9E6E5;
    border-radius: 8px;
    margin-left: 60px;
}
.calc .inp{
    padding: 10px;
    background: #F6F6F6;
}
.calc .inp .el-input >>> .el-input__inner{
    font-family: PingFangSC-Regular;
    font-size: 20px;
    color: #000;
}
.calc table{
    width: 100%;
}
.calc table td{
    width: 33.3333333333%;
}
.calc table .van-button{
    width: 100%;
    border-radius: 0;
    height: 60px;
    line-height: 60px;
}
.calc table .van-button >>> .van-button__text{
    font-family: PingFangSC-Medium;
    font-size: 32px;
    color: #5E606C;
}
</style>