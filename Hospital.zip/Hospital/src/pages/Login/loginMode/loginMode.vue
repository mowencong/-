<template>
    <div>
        <div class="header">
            <img src="../../../assets/img/logo.png" alt="">
            
            <div class="detail">
                <div class="countDown">
                    <van-circle
                        v-model="currentRate"
                        :rate="rate"
                        :speed="100"
                        :text="text"
                        :stroke-width="100"
                        color="#5D5D5D"
                    />
                </div>
                <div class="info">
                    <div class="tui">
                        <div class="name">赵敏</div>
                    </div>
                    <div class="time">
                        {{time}}
                    </div>
                </div>
            </div>
        </div>
        <top :title="title" :isHome='isHome'></top>
        <div class="content">
            <div class="cc">
                <van-row style="width:100%;margin:33px auto;" :gutter="20">
                    <van-col :span="8">
                        <div class="item" @click="goVisitingCardLogin">
                            <img src="../../../assets/img/VisitingCard.png" alt="">
                            <div class="con">
                                <div class="name">就诊卡</div>
                                <div class="subTitle">Establish</div>
                            </div>
                        </div>
                    </van-col>
                    <van-col :span="8">
                        <div class="item">
                            <img src="../../../assets/img/FaceRecognition.png" alt="">
                            <div class="con">
                                <div class="name">人脸识别</div>
                                <div class="subTitle">Establish</div>
                            </div>
                        </div>
                    </van-col>
                    <van-col :span="8">
                        <div class="item" @click="goIdentityCardLogin">
                            <img src="../../../assets/img/ID.png" alt="">
                            <div class="con">
                                <div class="name">身份证</div>
                                <div class="subTitle">Establish</div>
                            </div>
                        </div>
                    </van-col>
                    <van-col :span="8">
                        <div class="item" @click="goSocialSecurityCardLogin">
                            <img src="../../../assets/img/SocialSecurityCard.png" alt="">
                            <div class="con">
                                <div class="name">社保卡</div>
                                <div class="subTitle">Establish</div>
                            </div>
                        </div>
                    </van-col>
                    <!-- <van-col :span="8">
                        <div class="item" @click="goHospitalizationlogin">
                            <img src="../../../assets/img/ResidencePermitOfHongKong, MacaoAndTaiwan.png" alt="">
                            <div class="con">
                                <div class="name">住院单号</div>
                                <div class="subTitle">Establish</div>
                            </div>
                        </div>
                    </van-col> -->
                    <!-- <van-col :span="8">
                        <div class="item" @click="goResidentHealthCardLogin">
                            <img src="../../../assets/img/ResidentHealthCard.png" alt="">
                            <div class="con">
                                <div class="name">居民健康卡</div>
                                <div class="subTitle">Establish</div>
                            </div>
                        </div>
                    </van-col> -->
                    <!-- <van-col :span="8">
                        <div class="item">
                            <img src="../../assets/img/ResidentElectronicHealthCode.png" alt="">
                            <div class="con">
                                <div class="name">居民电子健康码</div>
                                <div class="subTitle">Establish</div>
                            </div>
                        </div>
                    </van-col> -->
                </van-row>
            </div>
        </div>
    </div>
</template>

<script>
import head from '../../../components/head'
export default {
    data(){
        return{
            title:'请选择登陆方式',
            isHome:false,
            currentRate: 0,
            currentTime:0,
            rate:0,
            total:120,
            timer:null,
            timer2:null,
            time:''
        }
    },
    components:{
        'top':head
    },
    computed: {
        text() {
            return this.currentTime.toFixed(0) + 's'
        }
    },
    created(){
        this.getDate();
        this.getTime();
    },
    mounted(){
        // this.set();
    },
    methods:{
        // 就诊卡登录
        goVisitingCardLogin(){
            this.$router.push('/visitingCardLogin');
        },
        // 身份证登录
        goIdentityCardLogin(){
            this.$router.push('/identityCardLogin');
        },
        // 居民健康卡登录
        goResidentHealthCardLogin(){
            this.$router.push('/residentHealthCardLogin');
        },
        // 社保卡登录
        goSocialSecurityCardLogin(){
            this.$router.push('/socialSecurityCardLogin');
        },
        // 住院单登录
        goHospitalizationlogin(){
            this.$router.push('/hospitalizationlogin');
        },
        set(){
            let total = this.total;
            let that = this;
            let timer = setInterval(function(){
                let currentRate = that.currentRate;
                let currentTime = that.currentTime;
                currentTime++;
                currentRate = currentTime / total * 100;
                currentRate = parseInt(currentRate);
                that.currentTime = currentTime;
                that.currentRate = currentRate;
                if(total==currentTime){
                    clearInterval(timer);
                    that.$router.push('/index');
                    return;
                }
                
            },1000)
            this.timer = timer;
        },
        getDate(){
            let myDate = new Date();
            let year = myDate.getFullYear();
            let month = myDate.getMonth() + 1;
            let date = myDate.getDate();
            let hour = myDate.getHours();
            let minute = myDate.getMinutes();
            let second = myDate.getSeconds();
            if(month<10){
                month = '0' + month;
            }
            if(date<10){
                date = '0' + date;
            }
            if(hour<10){
                hour = '0' + hour;
            }
            if(minute<10){
                minute = '0' + minute;
            }
            if(second<10){
                second = '0' + second;
            }
            let str = `${year}年${month}月${date}日 ${hour}:${minute}:${second}`;
            this.time = str;
        },
        // 获取当前时间
        getTime(){
            let timer2 = setInterval(()=>{
                this.getDate();
            },1000)
            this.timer2 = timer2;
        },
    },
    beforeDestroy(){
        clearInterval(this.timer);
        clearInterval(this.timer2);
    }
}
</script>

<style scoped>
.van-circle >>> .van-circle__text{
    font-family: PingFangSC-Regular;
    font-size: 40px;
    color: #5D5D5D;
    font-weight: bold;
}
.content{
    background: #EBF6F5;
    height: 529.41px;
    margin: 0 auto;
    width: 1109.76px;
    margin-top: 33px;
}
.cc{
    width: 96%;
    margin: 33px auto;
    display: flex;
    flex-wrap: wrap;
    align-items: center;
}
.van-col{
    margin-bottom: 30px;
}
.content .item{
    width: 330.24px;
    height: 100.35px;
    background: #FFFFFF;
    box-shadow: 0 3px 9px 0 rgba(206,215,222,0.52);
    border-radius: 8px;
    display: flex;
    align-items: center;
    cursor: pointer;
}
.content .item img{
    width: 55.04px;
    height: 43.01px;
    margin-right: 17.92px;
    margin-left: 26.88px;
}
.content .item .name{
    font-family: PingFangSC-Regular;
    font-size: 24px;
    color: #5D5D5D;
}
.content .item .subTitle{
    font-family: PingFangSC-Regular;
    font-size: 14px;
    color: #5D5D5D;
    margin-top: 5px;
}
</style>