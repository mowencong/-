<template>
    <div>
        <div class="header">
            <img src="../../../assets/img/logo.png" alt="">

            <div class="detail"  v-if="this.$store.state.login">
                <div class="countDown">
                    <van-circle
                        v-model="currentRate"
                        :rate="rate"
                        :speed="100"
                        :text="text"
                        :stroke-width="100"
                        color="#5D5D5D"
                    />
                </div>
                <div class="info">
                    <div class="tui">
                        <div class="name">赵敏</div>

                        <div class="tuika" @click="tuika">
                            <div>退卡</div>
                        </div>
                    </div>
                    <div class="time">
                        {{time}}
                    </div>
                </div>
            </div>

            <div class="tuika" @click="login" style="margin-right:50px;" v-if="!this.$store.state.login">
                <div>登录</div>
            </div>
        </div>
        
        <top :title="title" :isHome='isHome'></top>

        <div class="content" v-if="!detail">
            <div class="left">
                <div class="item" :class="[active==0? 'active':'']" v-if="active==0" @click="choose(0)">
                    <img src="../../../assets/img/juhe.png" alt=""> 聚合支付
                </div>
                <div class="item" :class="[active==1? 'active':'']" v-if="active==1" @click="choose(1)">
                    <img src="../../../assets/img/face.png" alt=""> 刷脸支付
                </div>
                <div class="item" :class="[active==2? 'active':'']" v-if="active==2" @click="choose(2)">
                    <img src="../../../assets/img/card.png" alt=""> 银行卡支付
                </div>
                <div class="item" :class="[active==3? 'active':'']" v-if="active==3" @click="choose(3)">
                    <img src="../../../assets/img/SocialSecurityCard.png" alt=""> 社保卡支付
                </div>
                <div class="item" :class="[active==4? 'active':'']" v-if="active==4" @click="choose(4)">
                    <img src="../../../assets/img/cash.png" alt=""> 现金支付
                </div>
            </div>

            <!-- 聚合支付 -->
            <div class="right right1" v-if="active==0">
                <div class="top">
                    <div class="code">
                        <img src="https://img.yzcdn.cn/vant/cat.jpeg" alt="">
                    </div>
                    <div class="detail">
                        <div class="title">
                            打开APP_扫一扫支付
                        </div>
                        <div class="title2">
                            收款人方：粤北人民医院 <br>
                            订单号：20190314000001
                        </div>
                        <div class="price">
                            ¥ 500.00
                        </div>
                    </div>
                </div>
                <div class="bot">
                    <div class="item">
                        <img src="../../../assets/img/bank.png" alt="">
                        <div class="title">农银快e付</div>
                    </div>
                    <div class="item">
                        <img src="../../../assets/img/wechat.png" alt="">
                        <div class="title">微信支付</div>
                    </div>
                    <div class="item">
                        <img src="../../../assets/img/alipay.png" alt="">
                        <div class="title">支付宝支付</div>
                    </div>
                    <div class="item">
                        <img src="../../../assets/img/CloudFlashover.png" alt="">
                        <div class="title">云闪付</div>
                    </div>
                </div>
            </div>

            <!-- 刷脸支付 -->
            <div class="right right2" v-if="active==1">
                <div class="calc">
                    <div class="inp">
                        <el-input v-model="input" placeholder="请输入电子健康码"></el-input>
                    </div>
                    <div class="key">
                        <table cellpadding="0" cellspacing="0">
                            <tr>
                                <td>
                                    <van-button type="default" @click="ent(7)">7</van-button>
                                </td>
                                <td>
                                    <van-button type="default" @click="ent(8)">8</van-button>
                                </td>
                                <td>
                                    <van-button type="default" @click="ent(9)">9</van-button>
                                </td>
                            </tr>
                            <tr>
                                <td>
                                    <van-button type="default" @click="ent(4)">4</van-button>
                                </td>
                                <td>
                                    <van-button type="default" @click="ent(5)">5</van-button>
                                </td>
                                <td>
                                    <van-button type="default" @click="ent(6)">6</van-button>
                                </td>
                            </tr>
                            <tr>
                                <td>
                                    <van-button type="default" @click="ent(1)">1</van-button>
                                </td>
                                <td>
                                    <van-button type="default" @click="ent(2)">2</van-button>
                                </td>
                                <td>
                                    <van-button type="default" @click="ent(3)">3</van-button>
                                </td>
                            </tr>
                            <tr>
                                <td>
                                    <van-button type="default">&nbsp;</van-button>
                                </td>
                                <td>
                                    <van-button type="default" @click="ent(0)">0</van-button>
                                </td>
                                <td>
                                    <van-button type="default" @click="tui">3</van-button>
                                </td>
                            </tr>
                        </table>
                    </div>
                </div>

                <div class="detail">
                    <div class="title">
                        打开APP_扫一扫支付
                    </div>
                    <div class="title2">
                        收款人方：粤北人民医院 <br>
                        订单号：20190314000001
                    </div>
                    <div>
                        <div class="price">
                            ¥ 500.00
                        </div>
                        <div class="btn" @click="facePay">
                            <div>开始支付</div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- 银行卡支付 -->
            <div class="right right3" v-if="active==2">
                <div class="pic">
                    <img src="https://img.yzcdn.cn/vant/cat.jpeg" alt="">
                    <div class="note shan">
                        - 请将银行卡插入卡槽 -
                    </div>
                </div>
                <div class="detail">
                    <div class="detail">
                        <div class="title">
                            银行卡插卡支付
                        </div>
                        <div class="title2">
                            收款人方：粤北人民医院 <br>
                            订单号：20190314000001
                        </div>
                        <div>
                            <div class="price">
                                ¥ 500.00
                            </div>
                        </div>
                    </div>
                </div>
                <div class="btn" @click="card = true" style="position:absolute;right:0;bottom:30px;">
                    重新插卡
                </div>

                <!-- 输入支付密码 -->
                <van-popup v-model="showWord">
                    <div class="dialog">
                        <div class="head">
                            <div class="text">
                                请输入银行卡密码
                            </div>
                            <div class="text">
                                您本次支付的金额为￥ 550.00元
                            </div>
                            <div class="time">
                                温馨提示：（注意周围是否有可疑人物）
                            </div>
                            <van-password-input
                                :value="pwd"
                            />
                        </div>
                        <div class="mid">

                        </div>
                        <div class="bot">
                            <div @click="card = false">取消</div>
                            <div @click="showSuccess">确认</div>
                        </div>
                    </div>
                </van-popup>
            </div>

            <!-- 社保卡支付 -->
            <div class="right right3" v-if="active==3">
                <div class="pic">
                    <img src="https://img.yzcdn.cn/vant/cat.jpeg" alt="">
                    <div class="note shan">
                        - 请将社保卡插入卡槽 -
                    </div>
                </div>
                <div class="detail">
                    <div class="detail">
                        <div class="title">
                            社保卡插卡支付
                        </div>
                        <div class="title2">
                            收款人方：粤北人民医院 <br>
                            订单号：20190314000001
                        </div>
                        <div>
                            <div class="price">
                                ¥ 500.00
                            </div>
                        </div>
                    </div>
                </div>
                <div class="btn" @click="detail = true" style="position:absolute;right:0;bottom:30px;">
                    重新插卡
                </div>

                <!-- 输入支付密码 -->
                <van-popup v-model="socialSecurity">
                    <div class="dialog">
                        <div class="head">
                            <div class="text">
                                请输入银行卡密码
                            </div>
                            <div class="text">
                                您本次支付的金额为￥ 550.00元
                            </div>
                            <div class="time">
                                温馨提示：（注意周围是否有可疑人物）
                            </div>
                            <van-password-input
                                :value="pwd"
                            />
                        </div>
                        <div class="mid">

                        </div>
                        <div class="bot">
                            <div @click="socialSecurity = false">取消</div>
                            <div @click="showSuccess">确认</div>
                        </div>
                    </div>
                </van-popup>
            </div>

            <!-- 现金支付 -->
            <div class="right right3" v-if="active==4">
                <div class="pic">
                    <img src="https://img.yzcdn.cn/vant/cat.jpeg" alt="">
                    <div class="note shan ">
                        - 入钞口闪绿灯时放钞，一次一张 -
                    </div>
                </div>
                <div class="detail">
                    <div class="detail">
                        <div class="title">
                            现金支付
                        </div>
                        <div class="title2">
                            收款人方：粤北人民医院 <br>
                            订单号：20190314000001
                        </div>
                        <div>
                            <div class="price">
                                ¥ 500.00
                            </div>
                            <div class="title">
                                已放金额：<span class="price">500.00元</span>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="btn" @click="showSuccess" style="position:absolute;right:0;bottom:30px;">
                    确认支付
                </div>
            </div>


            <!-- 支付成功 -->
            <van-popup v-model="show">
                <div class="dialog">
                    <div class="head head2">
                        <div class="text">
                            交易成功 <br>
                            请取走您的缴费凭条！
                        </div>
                        <div class="time">
                            （3）S后自动关闭
                        </div>
                    </div>
                    <div class="mid">
                    </div>
                    <div class="bot" @click="popClose">
                        确定
                    </div>
                </div>
            </van-popup>

            <van-popup v-model="show2">
                <div class="dialog">
                    <div class="head head2">
                        <div class="text">
                            支付失败！
                        </div>
                        <div class="text">
                            请输入电子健康码！
                        </div>
                    </div>
                    <div class="mid">

                    </div>
                    <div class="bot" @click="show2 = false">
                        确定
                    </div>
                </div>
            </van-popup>
        </div>

        <div class="content2" v-if="detail">
            <div class="titleG">
                <div>姓名：</div>
                <div>就诊卡预存金额：</div>
                <div>医保账号余额：</div>
                <div>本次缴费总额：</div>
                <div>社保统筹报销金额：</div>
                <div>医保账户支付金额：</div>
                <div>自费需支付：</div>

                <div class="btn" @click="socialPay">
                    确认缴费
                </div>
            </div>
            <div class="nameG">
                <div>赵敏</div>
                <div>100.00元</div>
                <div>100.00元</div>
                <div class="price">650.00元</div>
                <div>250.00元</div>
                <div>250.00元</div>
                <div class="price">150.00元</div>

                <div class="btn" @click="detail = false">
                    取消返回
                </div>
            </div>
        </div>
    </div>
</template>

<script>
import head from '../../../components/head'
export default {
    data(){
        return{
            title:'自助挂号-请选择支付方式',
            isHome:false,
            showWord:false,
            show:false, //支付成功
            show2:false, //支付失败
            card:false, //银行卡
            socialSecurity:false, //社保卡
            popTime:null,
            active:'0',
            input:'',
            currentRate: 0,
            currentTime:0,
            rate:0,
            total:120,
            timer:null,
            timer2:null,
            time:'',
            pwd:'123',
            detail:false
        }
    },
    components:{
        'top':head
    },
    computed: {
        text() {
            return this.currentTime.toFixed(0) + 's'
        }
    },
    created(){
        this.getDate();
        this.getTime();
        this.active = this.$route.params.type;
    },
    mounted(){
        // this.set();
    },
    methods:{
        choose(index){
            let active = this.active;
            if(index==active){
                return;
            }else{
                this.active = index;
            }
        },
        // 输入
        ent(index){
            this.input += index;
        },
        // 退格
        tui(){
            let arr = this.input;
            arr = arr.split('');
            let len = arr.length-1;
            arr.splice(len,1);
            arr = arr.join('');
            this.input = arr;
        },
        // 刷脸
        facePay(){
            let input = this.input;
            if(input===''){
                this.show2 = true;
                return;
            }else{
                this.$router.push('/identityVerification');
            }
        },
        showSuccess(){
            this.show = true;
            this.card = false;
            this.popTime = setTimeout(()=>{
                this.show = false;
                this.$router.push('/qutpatientHomePage');
            },3000)
        },
        popClose(){
            this.show = false;
            clearTimeout(this.popTime);
            this.$router.push('/qutpatientHomePage');
        },
        // 社保卡支付
        socialPay(){
            this.detail = false;
            this.socialSecurity = true;
        },
        set(){
            let total = this.total;
            let that = this;
            let timer = setInterval(function(){
                let currentRate = that.currentRate;
                let currentTime = that.currentTime;
                currentTime++;
                currentRate = currentTime / total * 100;
                currentRate = parseInt(currentRate);
                that.currentTime = currentTime;
                that.currentRate = currentRate;
                if(total==currentTime){
                    this.$store.commit('down');
                    clearInterval(timer);
                    that.$router.push('/index');
                    return;
                }
                
            },1000)
            this.timer = timer;
        },
        getDate(){
            let myDate = new Date();
            let year = myDate.getFullYear();
            let month = myDate.getMonth() + 1;
            let date = myDate.getDate();
            let hour = myDate.getHours();
            let minute = myDate.getMinutes();
            let second = myDate.getSeconds();
            if(month<10){
                month = '0' + month;
            }
            if(date<10){
                date = '0' + date;
            }
            if(hour<10){
                hour = '0' + hour;
            }
            if(minute<10){
                minute = '0' + minute;
            }
            if(second<10){
                second = '0' + second;
            }
            let str = `${year}年${month}月${date}日 ${hour}:${minute}:${second}`;
            this.time = str;
        },
        // 获取当前时间
        getTime(){
            let timer2 = setInterval(()=>{
                this.getDate();
            },1000)
            this.timer2 = timer2;
        },
        login(){
            this.$log();
        },
        tuika(){
            this.$store.commit('tuika');
        }
    },
    beforeDestroy(){
        clearInterval(this.timer);
        clearInterval(this.timer2);
    }
}
</script>

<style scoped>
.countDown{
    margin-right: 30px;
}
.van-circle >>> .van-circle__text{
    font-family: PingFangSC-Regular;
    font-size: 40px;
    font-weight: bold;
    color: #5D5D5D;
}
.content{
    background: #fff;
    height: 529.41px;
    margin: 0 auto;
    width: 1109.76px;
    margin-top: 33px;
    border: 1px solid transparent;
    display: flex;
}
.left{
    width: 30%;
    height: 100%;
}
.left .item{
    width: 100%;
    height: 20%;
    display: flex;
    align-items: center;
    opacity: 0.6;
    font-family: PingFangSC-Medium;
    font-size: 26px;
    color: #919191;
    font-weight: bold;
    border-bottom: 1px solid #eee;
    cursor: pointer;
}
.left .item img{
    width: 66px;
    height: 66px;
    margin-left: 50px;
    margin-right: 20px;
}
.left .active{
    opacity: 1!important;
    background-color: #fff!important;
    color: #3FC7C5!important;
}
.right{
    width: 70%;
    height: 100%;
}

/* 聚合支付 */
.right1{
    display: flex;
    flex-direction: column;
    align-items: center;
}
.right1 .top{
    display: flex;
    width: 80%;
    display: flex;
    justify-content: space-between;
    border-bottom: 2px solid #ECECEC;
    padding-bottom: 30px;
    margin-top: 60px;
}
.right1 .top .code{
    width: 300px;
    height: 300px;
    background: #EEEEEE;
    display: flex;
    justify-content: center;
    align-items: center;
}
.right1 .top img{
    width: 280px;
    height: 280px;
}
.right1 .top .detail{
    display: flex;
    flex-direction: column;
    justify-content: space-between;
    margin-right: 10px;
}
.right1 .top .detail .title{
    font-family: PingFangSC-Semibold;
    font-size: 25px;
    color: #5E5E5E;
    font-weight: bold;
}
.right1 .top .detail .title2{
    opacity: 0.7;
    font-family: PingFangSC-Regular;
    font-size: 23px;
    color: #5E5E5E;
}
.right1 .top .detail .price{
    opacity: 0.7;
    font-family: PingFangSC-Semibold;
    font-size: 36px;
    color: #DA251C;
    font-weight: bold;
}
.right1 .bot{
   width: 80%;
   display: flex;
   justify-content: space-between; 
}
.right1 .bot .item{
    display: flex;
    flex-direction: column;
    align-items: center;
    margin-top: 20px;
}
.right1 .bot img{
    width: 50px;
    height: 50px;
}
.right1 .bot .item .title{
    font-family: PingFangSC-Regular;
    font-size: 18px;
    color: #8E8E8E;
    margin-top: 20px;
}

/* 刷脸支付 */
.right2{
    display: flex;
    justify-content: space-around;
    align-items: center;
}
.right2 .calc{
    width: 340px;
    /* height: 330px; */
    background: #fff;
    border: 1px solid #D9E6E5;
    border-radius: 8px;
}
.right2 .calc .inp{
    padding: 10px;
    background: #F6F6F6;
}
.right2 .calc .inp .el-input >>> .el-input__inner{
    font-family: PingFangSC-Regular;
    font-size: 20px;
    color: #000;
}
.right2 .calc table{
    width: 100%;
}
.right2 .calc table td{
    width: 33.3333333333%;
}
.right2 .calc table .van-button{
    width: 100%;
    border-radius: 0;
    height: 60px;
    line-height: 60px;
}
.right2 .calc table .van-button >>> .van-button__text{
    font-family: PingFangSC-Medium;
    font-size: 32px;
    color: #5E606C;
}
.right2 .detail{
    display:  flex;
    height: 302px;
    flex-direction: column;
    justify-content: space-between;
}
.right2 .detail .title{
    font-family: PingFangSC-Semibold;
    font-size: 25px;
    color: #5E5E5E;
    font-weight: bold;
}
.right2 .detail .title2{
    opacity: 0.7;
    font-family: PingFangSC-Regular;
    font-size: 23px;
    color: #5E5E5E;
}
.right2 .detail .price{
    opacity: 0.7;
    font-family: PingFangSC-Semibold;
    font-size: 36px;
    color: #DA251C;
    font-weight: bold;
    margin-bottom: 15px;
}

/* 银行卡支付 */
.right3{
    display: flex;
    align-items: center;
    justify-content: space-around;
    position: relative;
}
.right3 .pic{
    display: flex;
    flex-direction: column;
    align-items: center;
}
.right3 .pic img{
    width: 280px;
    height: 280px;
}
.right3 .pic .note{
    font-family: PingFangSC-Regular;
    font-size: 23px;
    color: #101010;
    text-align: center;
    margin-top: 15px;
    font-weight: bold;
}
.right3 .detail{
    display:  flex;
    height: 302px;
    flex-direction: column;
    justify-content: space-between;
}
.right3 .detail .title{
    font-family: PingFangSC-Semibold;
    font-size: 25px;
    color: #5E5E5E;
    font-weight: bold;
}
.right3 .detail .title2{
    opacity: 0.7;
    font-family: PingFangSC-Regular;
    font-size: 23px;
    color: #5E5E5E;
}
.right3 .detail .price{
    opacity: 0.7;
    font-family: PingFangSC-Semibold;
    font-size: 36px;
    color: #DA251C;
    font-weight: bold;
    margin-bottom: 15px;
}

/* 密码输入框 */
.van-password-input{
    width: 80%;
    margin: 0 auto;
    margin-top: 15px;
}
.van-password-input >>> li{
    border: 1px solid #eee;
}

.van-popup{
    overflow: visible;
    border-radius: 13px 13px 13px 13px;
    background-color: rgba(255, 255, 255, 0.8);
}
.dialog{
    width: 600px;
    height: 300px;
    display: flex;
    flex-direction: column;
}
.dialog .head{
    display: flex;
    flex-direction: column;
    align-items: center;
    padding: 15px;
    height: 200px;
    justify-content: center;
}
.dialog .head2{
    height: 160px;
}
.dialog .head .text{
    color: rgba(5, 145, 139, 0.8);
    font-size: 35px;
    text-align: center;
    font-family: SourceHanSansSC-regular;
}
.dialog .head .time{
    color: rgba(5, 145, 139, 0.8);
    font-size: 25px;
    text-align: center;
    font-family: SourceHanSansSC-regular;
    margin:  0 auto;
    margin-top: 15px;
}
.dialog .mid{
    width: 100%;
    height: 13px;
    background-color: rgba(5, 145, 139, 0.8);
}
.dialog .bot{
    display: flex;
    justify-content: center;
    align-items: center;
    flex: 1;
    color: rgba(5, 145, 139, 0.8);
    font-size: 35px;
    font-family: SourceHanSansSC-regular;
    cursor: pointer;
}
.dialog .bot div{
    width: 50%;
    text-align: center;
    height: 100%;
}
.dialog .bot div:nth-child(1){
    border-right: 1px solid rgba(5, 145, 139, 0.8);
}


.btn{
    width: 194.56px;
    height: 58px;
    display: flex;
    align-items: center;
    justify-content: center;
    background: #3FC7C5;
    box-shadow: 0 3px 9px 0 #C5D0D5;
    border-radius: 8px;
    font-family: PingFangSC-Regular;
    font-size: 30px;
    font-weight: bold;
    color: #FFFFFF;
    cursor: pointer;
    margin-right:15px;
}

/* 文字闪烁 */
@keyframes blink{
  0%{opacity: 1;}
  100%{opacity: 0;} 
}
/* 添加兼容性前缀 */
@-webkit-keyframes blink {
    0% { opacity: 1; }
    100% { opacity: 0; }
}
@-moz-keyframes blink {
    0% { opacity: 1; }
    100% { opacity: 0; }
}
@-ms-keyframes blink {
    0% {opacity: 1; } 
    100% { opacity: 0;}
}
@-o-keyframes blink {
    0% { opacity: 1; }
    100% { opacity: 0; }
}
/* 定义blink类*/
.shan{
    color: #dd4814;
    animation: blink 1s linear infinite;  
    /* 其它浏览器兼容性前缀 */
    -webkit-animation: blink 1s linear infinite;
    -moz-animation: blink 1s linear infinite;
    -ms-animation: blink 1s linear infinite;
    -o-animation: blink 1s linear infinite;
}

.content2{
    background: #fff;
    height: 529.41px;
    margin: 0 auto;
    width: 1109.76px;
    margin-top: 33px;
    border: 1px solid transparent;
    display: flex;
    justify-content: center;
}
.content2 .titleG{
    text-align: right;
    font-family: PingFangSC-Regular;
    font-size: 26px;
    line-height: 50px;
    font-weight: bold;
}
.content2 .nameG{
    text-align: left;
    font-family: PingFangSC-Regular;
    font-size: 26px;
    line-height: 50px;
    font-weight: bold;
}
.price{
    color: #FF4081;
}
</style>