<template>
    <div>
        <div class="header">
            <img src="../../../../assets/img/logo.png" alt="">
        </div>
        
        <top :title="title" :isHome='isHome'></top>

        <div class="content" :class="[success? 'success':'']">

            <!-- 验证 -->
            <div class="ava" v-if="!success">
                <!-- <div></div> -->
                <img src="https://img.yzcdn.cn/vant/cat.jpeg" alt="">
            </div>

            <!-- 验证成功 -->
            <div class="succ" v-if="success">
                <img src="../../../../assets/img/facesuccess.png" alt="">
                <div>验证成功</div>
            </div>
            
        </div>
    </div>
</template>

<script>
import head from '../../../../components/head'
export default {
    data(){
        return{
            title:'请直视摄像头',
            isHome:false,
            show:true,
            success:false
        }
    },
    components:{
        'top':head
    },
    methods:{
        go(){
            // this.$router.push('/chargeDetail');
        }
    }
}
</script>

<style scoped>
.content{
    background: #222328;
    height: 529.41px;
    margin: 0 auto;
    width: 1109.76px;
    margin-top: 33px;
    border: 1px solid transparent;
    display: flex;
    justify-content: center;
    align-items: center;
}
.success{
    background: #fff!important;
}

.content .ava{
    width: 400px;
    height: 400px;
    border-radius: 50%;
    border: 6px solid #15C2C6;
    padding: 10px;
    box-sizing: border-box;
    display: flex;
    align-items: center;
    justify-content: center;
}
.ava img{
    width: 100%;
    height: 100%;
    border-radius: 50%;
}
.succ{
    display: flex;
    flex-direction: column;
    align-items: center;
}
.succ div{
    font-family: PingFangSC-Semibold;
    font-size: 36px;
    color: #3FC7C5;
    font-weight: bold;
    margin-top: 20px;
}
</style>