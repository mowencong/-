<template>
    <div>
        <div class="header">
            <img src="../../assets/img/logo.png" alt="">
            

            <div class="detail"  v-if="this.$store.state.login">
                <div class="countDown">
                    <van-circle
                        v-model="currentRate"
                        :rate="rate"
                        :speed="100"
                        :text="text"
                        :stroke-width="100"
                        color="#5D5D5D"
                    />
                </div>
                <div class="info">
                    <div class="tui">
                        <div class="name">赵敏</div>

                        <div class="tuika" @click="tuika">
                            <div>退卡</div>
                        </div>
                    </div>
                    <div class="time">
                        {{time}}
                    </div>
                </div>
            </div>

            <div class="tuika" @click="login" style="margin-right:50px;" v-if="!this.$store.state.login">
                <div>登录</div>
            </div>
        </div>


        <top :title="title" :isHome='isHome' :homePage='homePage'></top>

        <div class="content">
            <img class="left" src="https://img.yzcdn.cn/vant/cat.jpeg" alt="">
            <div class="right">
                <div class="item" @click="goQutpatientHomePage">
                    <img src="https://img.yzcdn.cn/vant/cat.jpeg" alt="">
                    <div>门诊服务</div>
                </div>
                <div class="item" @click="goInpatientHomePage">
                    <img src="https://img.yzcdn.cn/vant/cat.jpeg" alt="">
                    <div>住院服务</div>
                </div>
            </div>
        </div>
    </div>
</template>

<script>
import head from '../../components/head'
// import header from '../../components/header'
export default {
    data(){
        return{
            title:'欢迎使用自助服务系统',
            isHome:true,
            homePage:true,
            currentRate: 0,
            currentTime:0,
            rate:0,
            total:120,
            timer:null,
            timer2:null,
            time:''
        }
    },
    computed: {
        text() {
            return this.currentTime.toFixed(0) + 's'
        }
    },
    components:{
        'top':head,
        // 'top1':header
    },
    created(){
        this.getDate();
        this.getTime();
    },
    mounted(){
        // if(this.$store.state.login){
        //     this.set();
        // }
    },
    methods:{
        // 前往门诊首页
        goQutpatientHomePage(){
            this.$router.push('/qutpatientHomePage');
        },
        // 前往住院首页
        goInpatientHomePage(){
            this.$router.push('/inpatientHomePage');
        },
        set(){
            let total = this.total;
            let that = this;
            let timer = setInterval(function(){
                let currentRate = that.currentRate;
                let currentTime = that.currentTime;
                currentTime++;
                currentRate = currentTime / total * 100;
                currentRate = parseInt(currentRate);
                that.currentTime = currentTime;
                that.currentRate = currentRate;
                if(total==currentTime){
                    this.$store.commit('down');
                    clearInterval(timer);
                    return;
                }
            },1000)
            this.timer = timer;
        },
        getDate(){
            let myDate = new Date();
            let year = myDate.getFullYear();
            let month = myDate.getMonth() + 1;
            let date = myDate.getDate();
            let hour = myDate.getHours();
            let minute = myDate.getMinutes();
            let second = myDate.getSeconds();
            if(month<10){
                month = '0' + month;
            }
            if(date<10){
                date = '0' + date;
            }
            if(hour<10){
                hour = '0' + hour;
            }
            if(minute<10){
                minute = '0' + minute;
            }
            if(second<10){
                second = '0' + second;
            }
            let str = `${year}年${month}月${date}日 ${hour}:${minute}:${second}`;
            this.time = str;
        },
        // 获取当前时间
        getTime(){
            let timer2 = setInterval(()=>{
                this.getDate();
            },1000)
            this.timer2 = timer2;
        },
        login(){
            this.$log();
        },
        tuika(){
            this.$store.commit('tuika');
        }
    },
    beforeDestroy(){
        clearInterval(this.timer);
        clearInterval(this.timer2);
    }
}
</script>

<style scoped>
.van-circle >>> .van-circle__text{
    font-family: PingFangSC-Regular;
    font-size: 40px;
    font-weight: bold;
    color: #5D5D5D;
}
.content{
    display: flex;
    margin: 0 auto;
    margin-top: 33px;
    width: 1109.76px;
    justify-content: space-between;
}
.content .left{
    width: 700px;
    height: 100%;
    border-radius: 8px;
}
.content .right{
    display: flex;
    flex-direction: column;
    justify-content: space-between;
}
.content .right .item{
    width: 370px;
    height: 230px;
    cursor: pointer;
    display: flex;
    flex-direction: column;
    align-items: center;
    background-color: #fff;
    justify-content: space-around;
    font-family: PingFangSC-Semibold;
    font-size: 28px;
    box-shadow: 0 3px 9px 0 rgba(206,215,222,0.52);
    border-radius: 8px;
}
.content .right .item img{
    width: 180px;
    height: 130px;
}

</style>