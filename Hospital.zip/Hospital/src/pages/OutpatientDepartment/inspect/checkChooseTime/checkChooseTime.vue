<template>
    <div>
        <div class="header">
            <img src="../../../../assets/img/logo.png" alt="">

            <div class="detail"  v-if="this.$store.state.login">
                <div class="countDown">
                    <van-circle
                        v-model="currentRate"
                        :rate="rate"
                        :speed="100"
                        :text="text"
                        :stroke-width="100"
                        color="#5D5D5D"
                    />
                </div>
                <div class="info">
                    <div class="tui">
                        <div class="name">赵敏</div>

                        <div class="tuika" @click="tuika">
                            <div>退卡</div>
                        </div>
                    </div>
                    <div class="time">
                        {{time}}
                    </div>
                </div>
            </div>

            <div class="tuika" @click="login" style="margin-right:50px;" v-if="!this.$store.state.login">
                <div>登录</div>
            </div>
        </div>
        
        <top :title="title" :isHome='isHome'></top>

        <div class="content">
            <div class="timeGroup">
                <van-row :gutter="20">
                    <van-col :span="3">
                        <div class="item" :class="[index==0? 'active':'']" @click="chooseDate(0)">
                            <div>今天</div>
                        </div>
                        <div class="xian" v-show="index==0"></div>
                    </van-col>
                    <van-col :span="3">
                        <div class="item" :class="[index==1? 'active':'']" @click="chooseDate(1)">
                            <div>03月12日</div>
                        </div>
                        <div class="xian" v-show="index==1"></div>
                    </van-col>
                    <van-col :span="3">
                        <div class="item" :class="[index==2? 'active':'']" @click="chooseDate(2)">
                            <div>03月12日</div>
                        </div>
                        <div class="xian" v-show="index==2"></div>
                    </van-col>
                    <van-col :span="3">
                        <div class="item" :class="[index==3? 'active':'']" @click="chooseDate(3)">
                            <div>03月12日</div>
                        </div>
                        <div class="xian" v-show="index==3"></div>
                    </van-col>
                    <van-col :span="3">
                        <div class="item" :class="[index==4? 'active':'']" @click="chooseDate(4)">
                            <div>03月12日</div>
                        </div>
                        <div class="xian" v-show="index==4"></div>
                    </van-col>
                    <van-col :span="3">
                        <div class="item" :class="[index==5? 'active':'']" @click="chooseDate(5)">
                            <div>03月12日</div>
                        </div>
                        <div class="xian" v-show="index==5"></div>
                    </van-col>
                    <van-col :span="3">
                        <div class="item" :class="[index==6? 'active':'']" @click="chooseDate(6)">
                            <div>03月12日</div>
                        </div>
                        <div class="xian" v-show="index==6"></div>
                    </van-col>
                    <van-col :span="3">
                        <div class="item" :class="[index==7? 'active':'']" @click="chooseDate(7)">
                            <div>03月12日</div>
                        </div>
                        <div class="xian" v-show="index==7"></div>
                    </van-col>
                </van-row>
            </div>

            <div class="con">
                <div class="left">
                    <div class="title">检查须知</div>
                    <div class="note">
                        磁共振检查具有安全、无辐射、精确等优点，检查时不要穿着带有金属物质的内衣裤，检查头、颈部的病人应在检查前一天洗头，不要擦任何护发用品。做磁共振检查要有思想准备，不要急躁、害怕，要听从医师的指导，耐心配合。
                    </div>
                </div>
                <div class="right">
                    <div class="item" @click="go">
                        上午 08:00-09:00（剩余&nbsp; <span>10</span> &nbsp;号）
                    </div>
                    <div class="item">
                        上午 08:00-09:00（剩余&nbsp; <span>10</span> &nbsp;号）
                    </div>
                    <div class="item">
                        上午 08:00-09:00（剩余&nbsp; <span>10</span> &nbsp;号）
                    </div>
                    <div class="item">
                        上午 08:00-09:00（剩余&nbsp; <span>10</span> &nbsp;号）
                    </div>
                    <div class="item">
                        上午 08:00-09:00（剩余&nbsp; <span>10</span> &nbsp;号）
                    </div>
                    <div class="item">
                        上午 08:00-09:00（剩余&nbsp; <span>10</span> &nbsp;号）
                    </div>
                </div>
            </div>
        </div>
    </div>
</template>

<script>
import head from '../../../../components/head'
export default {
    data(){
        return{
            title:'自助挂号-请选择挂号时间',
            isHome:false,
            currentRate: 0,
            currentTime:0,
            rate:0,
            total:120,
            timer:null,
            index:0
        }
    },
    components:{
        'top':head
    },
    computed: {
        text() {
            return this.currentTime.toFixed(0) + 's'
        }
    },
    created(){
        this.getDate();
        this.getTime();
    },
    mounted(){
        // this.set();
    },
    methods:{
        go(){
            this.$router.push('/checkInformation');
        },
        chooseDate(index){
            this.index = index;
        },
        set(){
            let total = this.total;
            let that = this;
            let timer = setInterval(function(){
                let currentRate = that.currentRate;
                let currentTime = that.currentTime;
                currentTime++;
                currentRate = currentTime / total * 100;
                currentRate = parseInt(currentRate);
                that.currentTime = currentTime;
                that.currentRate = currentRate;
                if(total==currentTime){
                    this.$store.commit('down');
                    clearInterval(timer);
                    that.$router.push('/index');
                    return;
                }
                
            },1000)
            this.timer = timer;
        },
        getDate(){
            let myDate = new Date();
            let year = myDate.getFullYear();
            let month = myDate.getMonth() + 1;
            let date = myDate.getDate();
            let hour = myDate.getHours();
            let minute = myDate.getMinutes();
            let second = myDate.getSeconds();
            if(month<10){
                month = '0' + month;
            }
            if(date<10){
                date = '0' + date;
            }
            if(hour<10){
                hour = '0' + hour;
            }
            if(minute<10){
                minute = '0' + minute;
            }
            if(second<10){
                second = '0' + second;
            }
            let str = `${year}年${month}月${date}日 ${hour}:${minute}:${second}`;
            this.time = str;
        },
        // 获取当前时间
        getTime(){
            let timer2 = setInterval(()=>{
                this.getDate();
            },1000)
            this.timer2 = timer2;
        },
        login(){
            this.$log();
        },
        tuika(){
            this.$store.commit('tuika');
        }
    },
    beforeDestroy(){
        clearInterval(this.timer);
    }
}
</script>

<style scoped>
.van-circle >>> .van-circle__text{
    font-family: PingFangSC-Regular;
    font-size: 40px;
    font-weight: bold;
    color: #5D5D5D;
}
.content{
    background: #EBF6F5;
    height: 529.41px;
    margin: 0 auto;
    width: 1109.76px;
    margin-top: 33px;
    border: 1px solid transparent;
}
.timeGroup{
    margin: 20px auto;
    width: 90%;
}
.timeGroup .item{
    width: 99.84px;
    height: 30px;
    display: flex;
    justify-content: center;
    cursor: pointer;
}
.timeGroup .active{
    color: #3FC7C5!important;
}
.timeGroup .item div{
    text-align: center;
    font-family: PingFangSC-Medium;
    font-size: 20px;
    color: #919191;
    font-weight: bold;
}
.timeGroup .active div{
    color: #3FC7C5!important;
}
.timeGroup .xian{
    width: 99.84px;
    height: 4px;
    background: #3FC7C5;
    border-radius: 4px;
}

.con{
    width: 93%;
    margin: 30px auto;
    display: flex;
    justify-content: space-between;
}
.con .left{
    width: 45%;
    height: 401.41px;
    background: #FFFFFF;
    box-shadow: 0 3px 9px 0 rgba(206,215,222,0.52);
    border-radius: 8px;
    padding: 20px;
    box-sizing: border-box;
    display: flex;
    flex-direction: column;
}
.con .left .title{
    font-family: SourceHanSansCN-Normal;
    font-size: 30px;
    font-weight: bold;
    color: #000;
}
.con .left .note{
    font-family: SourceHanSansCN-Normal;
    font-size: 26px;
    font-weight: bold;
    color: #9D9E9E;
}


.con .right{
    width: 50%;
    height: 401.41px;
    background: #FFFFFF;
    box-shadow: 0 3px 9px 0 rgba(206,215,222,0.52);
    border-radius: 8px;
}
.con .right .item{
    width: 100%;
    height: 67px;
    display: flex;
    align-items: center;
    justify-content: center;
    font-family: SourceHanSansCN-Normal;
    font-size: 20px;
    font-weight: bold;
    color: #9D9E9E;
    border-bottom: 1px solid #eee;
    cursor: pointer;
}
.con .right .item span{
    color: #FF8648;
}
</style>