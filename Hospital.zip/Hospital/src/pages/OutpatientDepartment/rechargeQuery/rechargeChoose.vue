<template>
  <div>
    <div class="header">
      <img src="../../../assets/img/logo.png" alt />
      <div class="detail"  v-if="this.$store.state.login">
                <div class="countDown">
                    <van-circle
                        v-model="currentRate"
                        :rate="rate"
                        :speed="100"
                        :text="text"
                        :stroke-width="100"
                        color="#5D5D5D"
                    />
                </div>
                <div class="info">
                    <div class="tui">
                        <div class="name">赵敏</div>

                        <div class="tuika" @click="tuika">
                            <div>退卡</div>
                        </div>
                    </div>
                    <div class="time">
                        {{time}}
                    </div>
                </div>
            </div>

            <div class="tuika" @click="login" style="margin-right:50px;" v-if="!this.$store.state.login">
                <div>登录</div>
            </div>
    </div>

    <top title="请选择充值金额" :isHome="false"></top>

    <div class="content">
      <el-row :gutter="20" style="display:flex;flex-wrap: wrap;justify-content: space-around;">
        <el-col :span="24">
          <div>
            <span>请选择充值金额:</span>
          </div>
        </el-col>
        <el-col :span="4">
          <div class="pay-choose" :class="{'selected':cashIndex===0}" @click="cashIndex=0">
            <span>100.00元</span>
          </div>
        </el-col>
        <el-col :span="4">
          <div class="pay-choose" :class="{'selected':cashIndex===1}" @click="cashIndex=1">
            <span>500.00元</span>
          </div>
        </el-col>
        <el-col :span="4">
          <div class="pay-choose" :class="{'selected':cashIndex===2}" @click="cashIndex=2">
            <span>1000.00元</span>
          </div>
        </el-col>
        <el-col :span="4">
          <div class="pay-choose" :class="{'selected':cashIndex===3}" @click="cashIndex=3">
            <span>其他金额</span>
          </div>
        </el-col>
      </el-row>
      <div class="submit" @click="jumpTo">确认</div>
    </div>
  </div>
</template>

<script>
import head from "../../../components/head";
export default {
  data() {
    return {
      currentRate: 0,
      currentTime: 0,
      rate: 0,
      total: 120,
      timer: null,
      timer2: null,
      time: "",
      cashIndex:0
    };
  },
  components: {
    top: head
  },
  computed: {
    text() {
      return this.currentTime.toFixed(0) + "s";
    }
  },
  created() {
    this.getDate();
    this.getTime();
  },
  mounted() {
    // this.set();
  },
  methods: {
    go() {
      this.$router.push("/chooseTime");
    },
    set() {
      let total = this.total;
      let that = this;
      let timer = setInterval(function() {
        let currentRate = that.currentRate;
        let currentTime = that.currentTime;
        currentTime++;
        currentRate = (currentTime / total) * 100;
        currentRate = parseInt(currentRate);
        that.currentTime = currentTime;
        that.currentRate = currentRate;
        if (total == currentTime) {
          this.$store.commit('down');
          clearInterval(timer);
          that.$router.push("/index");
          return;
        }
      }, 1000);
      this.timer = timer;
    },
    getDate() {
      let myDate = new Date();
      let year = myDate.getFullYear();
      let month = myDate.getMonth() + 1;
      let date = myDate.getDate();
      let hour = myDate.getHours();
      let minute = myDate.getMinutes();
      let second = myDate.getSeconds();
      if (month < 10) {
        month = "0" + month;
      }
      if (date < 10) {
        date = "0" + date;
      }
      if (hour < 10) {
        hour = "0" + hour;
      }
      if (minute < 10) {
        minute = "0" + minute;
      }
      if (second < 10) {
        second = "0" + second;
      }
      let str = `${year}年${month}月${date}日 ${hour}:${minute}:${second}`;
      this.time = str;
    },
    // 获取当前时间
    getTime() {
      let timer2 = setInterval(() => {
        this.getDate();
      }, 1000);
      this.timer2 = timer2;
    },
    jumpTo(){
        this.$router.push('/payType/0')
    },
        login(){
            this.$log();
        },
        tuika(){
            this.$store.commit('tuika');
        }
  },
  beforeDestroy() {
    clearInterval(this.timer);
    clearInterval(this.timer2);
  }
};
</script>

<style scoped>
.van-circle >>> .van-circle__text{
    font-family: PingFangSC-Regular;
    font-size: 40px;
    font-weight: bold;
    color: #5D5D5D;
}
.content {
  background: #ebf6f5;
  position: relative;
  height: 529.41px;
  margin: 0 auto;
  width: 1109.76px;
  margin-top: 33px;
  border: 1px solid transparent;
  padding: 30px 1rem;
}

.el-col {
  margin-bottom: 30px;
}

.el-col:last-child {
  margin-bottom: 0;
}

.el-col > div {
  border-radius: 4px;
  padding: 15px 0;
  color: #5d5d5d;
  font-size: 26px;
}

.pay-choose {
  display: flex;
  align-items: center;
  justify-content: center;
  cursor: pointer;
  background: white;
  border: 1px solid #3fc7c5;
  user-select: none;
  -webkit-user-select: none;
}

.pay-choose.selected {
  color: white;
  background: #3fc7c5;
}

.submit {
    position: absolute;
    bottom: 30px;
    right: 30px;
  width: 156px;
  height: 44px;
  display: -webkit-box;
  display: -ms-flexbox;
  display: flex;
  -webkit-box-pack: center;
  -ms-flex-pack: center;
  justify-content: center;
  -webkit-box-align: center;
  -ms-flex-align: center;
  align-items: center;
  border: 2px solid #3fc7c5;
  background: #3fc7c5;
  font-family: PingFangSC-Regular;
  font-size: 30px;
  font-weight: bold;
  color: #ffffff;
  border-radius: 8px;
  cursor: pointer;
}
</style>