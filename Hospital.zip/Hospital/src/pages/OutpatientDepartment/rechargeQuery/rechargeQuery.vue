<template>
  <div>
    <div class="header">
      <img src="../../../assets/img/logo.png" alt />
      <div class="detail"  v-if="this.$store.state.login">
                <div class="countDown">
                    <van-circle
                        v-model="currentRate"
                        :rate="rate"
                        :speed="100"
                        :text="text"
                        :stroke-width="100"
                        color="#5D5D5D"
                    />
                </div>
                <div class="info">
                    <div class="tui">
                        <div class="name">赵敏</div>

                        <div class="tuika" @click="tuika">
                            <div>退卡</div>
                        </div>
                    </div>
                    <div class="time">
                        {{time}}
                    </div>
                </div>
            </div>

            <div class="tuika" @click="login" style="margin-right:50px;" v-if="!this.$store.state.login">
                <div>登录</div>
            </div>
    </div>

    <top title="充值查询" :isHome="false"></top>

    <div class="content">
      <el-row :gutter="20">
        <el-col :span="24">
          <div>
            <span style="margin-right:1.2rem">就诊卡余额:</span>
            <span style="color:red">1000.00元</span>
          </div>
        </el-col>
        <el-col :span="24">
          <el-row :gutter="20">
            <el-col :span="24">
              <div>
                <span>请选择以下方式进行充值:</span>
              </div>
            </el-col>
            <el-col :span="6">
              <div class="pay-choose" @click="jumpTo">
                <div class="images">
                  <img src="../../../assets/img/bank.png" alt />
                </div>
                <span>农银快e付</span>
              </div>
            </el-col>
            <el-col :span="6">
              <div class="pay-choose" @click="goFace">
                <div class="images">
                  <img src="../../../assets/img/face.png" alt />
                </div>
                <span>刷脸支付</span>
              </div>
            </el-col>
            <el-col :span="6">
              <div class="pay-choose" @click="goCash">
                <div class="images">
                  <img src="../../../assets/img/cash.png" alt />
                </div>
                <span>现金支付</span>
              </div>
            </el-col>
            <el-col :span="6">
              <div class="pay-choose" @click="goCard">
                <div class="images">
                  <img src="../../../assets/img/CloudFlashover.png" alt />
                </div>
                <span>银行卡支付</span>
              </div>
            </el-col>
          </el-row>
        </el-col>
      </el-row>
    </div>
  </div>
</template>

<script>
import head from "../../../components/head";
export default {
  data() {
    return {
      currentRate: 0,
      currentTime: 0,
      rate: 0,
      total: 120,
      timer: null,
      timer2: null,
      time: ""
    };
  },
  components: {
    top: head
  },
  computed: {
    text() {
      return this.currentTime.toFixed(0) + "s";
    }
  },
  created() {
    this.getDate();
    this.getTime();
  },
  mounted() {
    // this.set();
  },
  methods: {
    go() {
      this.$router.push("/chooseTime");
    },
    goFace(){
      this.$router.push({
        name:'payType',
        params:{
          type:1
        }
      })
    },
    goCash(){
      this.$router.push({
        name:'payType',
        params:{
          type:4
        }
      })
    },
    goCard(){
      this.$router.push({
        name:'payType',
        params:{
          type:2
        }
      })
    },
    set() {
      let total = this.total;
      let that = this;
      let timer = setInterval(function() {
        let currentRate = that.currentRate;
        let currentTime = that.currentTime;
        currentTime++;
        currentRate = (currentTime / total) * 100;
        currentRate = parseInt(currentRate);
        that.currentTime = currentTime;
        that.currentRate = currentRate;
        if (total == currentTime) {
          this.$store.commit('down');
          clearInterval(timer);
          that.$router.push("/index");
          return;
        }
      }, 1000);
      this.timer = timer;
    },
    getDate() {
      let myDate = new Date();
      let year = myDate.getFullYear();
      let month = myDate.getMonth() + 1;
      let date = myDate.getDate();
      let hour = myDate.getHours();
      let minute = myDate.getMinutes();
      let second = myDate.getSeconds();
      if (month < 10) {
        month = "0" + month;
      }
      if (date < 10) {
        date = "0" + date;
      }
      if (hour < 10) {
        hour = "0" + hour;
      }
      if (minute < 10) {
        minute = "0" + minute;
      }
      if (second < 10) {
        second = "0" + second;
      }
      let str = `${year}年${month}月${date}日 ${hour}:${minute}:${second}`;
      this.time = str;
    },
    // 获取当前时间
    getTime() {
      let timer2 = setInterval(() => {
        this.getDate();
      }, 1000);
      this.timer2 = timer2;
    },
    jumpTo() {
      this.$router.push("/rechargeChoose");
    },
    login(){
            this.$log();
        },
        tuika(){
            this.$store.commit('tuika');
        }
  },
  beforeDestroy() {
    clearInterval(this.timer);
    clearInterval(this.timer2);
  }
};
</script>

<style scoped>
.van-circle >>> .van-circle__text{
    font-family: PingFangSC-Regular;
    font-size: 40px;
    font-weight: bold;
    color: #5D5D5D;
}
.content {
  background: #ebf6f5;
  height: 529.41px;
  margin: 0 auto;
  width: 1109.76px;
  margin-top: 33px;
  border: 1px solid transparent;
  padding: 30px 1rem;
}

.el-col {
  margin-bottom: 30px;
}

.el-col:last-child {
  margin-bottom: 0;
}

.el-col > div {
  border-radius: 4px;
  padding: 15px 0;
  color: #5d5d5d;
  font-size: 26px;
}

.pay-choose {
  display: flex;
  align-items: center;
  cursor: pointer;
  user-select: none;
  -webkit-user-select: none;
}

.pay-choose:hover {
  color: #000;
}

.images {
  position: relative;
  display: inline-block;
  width: 60px;
  height: 50px;
  margin-right: 1rem;
}
.images img {
  position: absolute;
  left: 50%;
  top: 50%;
  transform: translate(-50%, -50%);
  height: 100%;
  width: auto;
}
</style>