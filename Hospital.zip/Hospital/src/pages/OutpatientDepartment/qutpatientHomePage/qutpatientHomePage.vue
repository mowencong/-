<template>
    <div>
        <div class="header">
            <img src="../../../assets/img/logo.png" alt="">
            

            <div class="detail"  v-if="this.$store.state.login">
                <div class="countDown">
                    <van-circle
                        v-model="currentRate"
                        :rate="rate"
                        :speed="100"
                        :text="text"
                        :stroke-width="100"
                        color="#5D5D5D"
                    />
                </div>
                <div class="info">
                    <div class="tui">
                        <div class="name">赵敏</div>

                        <div class="tuika" @click="tuika">
                            <div>退卡</div>
                        </div>
                    </div>
                    <div class="time">
                        {{time}}
                    </div>
                </div>
            </div>

            <div class="tuika" @click="login" style="margin-right:50px;" v-if="!this.$store.state.login">
                <div>登录</div>
            </div>
        </div>
        <top :title="title" :isHome='isHome' :homePage='homePage'></top>
        <div class="content">
            <div class="item" @click="goPerfectingPersonalInformation">
                <img src="../../../assets/img/InitialFiling.png" alt="">
                <div class="name">初诊建档</div>
                <div class="subTitle">Establish</div>
            </div>
            <div class="item" @click="go">
                <img src="../../../assets/img/SelfHelpRegistration.png" alt="">
                <div class="name">自助挂号</div>
                <div class="subTitle">Register</div>
            </div>
            <div class="item" @click="goReportToTheDoctorList">
                <img src="../../../assets/img/VisitingReport.png" alt="">
                <div class="name">就诊报道</div>
                <div class="subTitle">Visiting Report</div>
            </div>
            <div class="item" @click="goListOfPendingCharges">
                <img src="../../../assets/img/SelfServicePayment.png" alt="">
                <div class="name">自助缴费</div>
                <div class="subTitle">Self-help Pay</div>
            </div>
            <div class="item" @click="goListToBeChecked">
                <img src="../../../assets/img/AppointmentCheck.png" alt="">
                <div class="name">预约检查</div>
                <div class="subTitle">Inspect</div>
            </div>

            <div class="item mt" @click="goListOfChecked">
                <img src="../../../assets/img/TakingMedicineReport.png" alt="">
                <div class="name">取药报道</div>
                <div class="subTitle"> Medicine Report</div>
            </div>
            <div class="item mt" @click="show = true">
                <img src="../../../assets/img/SelfHelpPrinting.png" alt="">
                <div class="name">自助打印</div>
                <div class="subTitle">Printing</div>
            </div>
            <div class="item mt" @click="goRechargeQuery">
                <img src="../../../assets/img/RechargeQuery.png" alt="">
                <div class="name">充值查询</div>
                <div class="subTitle">Recharge</div>
            </div>
            <div class="item item2">
                <img src="../../../assets/img/MedicalInsuranceAuthorization.png" alt="">
                <div class="name">医保授权</div>
                <div class="subTitle">Authorization</div>
            </div>
        </div>

        <!-- 自助打印 -->
        <van-popup v-model="show">
            <div class="dialog">
                <div class="close" @click="show = false">
                    <div>X</div>
                </div>
                <div class="top">
                    请选择打印类型
                </div>
                <div class="bot">
                    <div class="btn" @click="goListOfReportsToBePrinted">
                        <img src="https://img.yzcdn.cn/vant/cat.jpeg" alt="">
                        检查报告
                    </div>
                    <div class="btn" @click="goListToBePrinted">
                        <img src="https://img.yzcdn.cn/vant/cat.jpeg" alt="">
                        费用清单
                    </div>
                    <div class="btn">
                        <img src="https://img.yzcdn.cn/vant/cat.jpeg" alt="">
                        电子病历
                    </div>
                </div>
            </div>
        </van-popup>
    </div>
</template>

<script>
import head from '../../../components/head'
export default {
    data(){
        return{
            title:'欢迎使用门诊服务！',
            isHome:false,
            homePage:true,
            timeShow:false,
            currentRate: 0,
            currentTime:0,
            rate:0,
            total:120,
            timer:null,
            timer2:null,
            time:'',
            show:false
        }
    },
    computed: {
        text() {
            return this.currentTime.toFixed(0) + 's'
        }
    },
    components:{
        'top':head
    },
    created(){
        this.getDate();
        this.getTime();
    },
    mounted(){
        // this.set();
    },
    methods:{
        // 自助挂号
        go(){
            this.$router.push('/noticeOfRegistration')
        },
        goListOfPendingCharges(){
            this.$router.push('/listOfPendingCharges')
        },
        // 前往报到列表
        goListOfChecked(){
            this.$router.push('/listOfChecked')
        },
        // 完善个人信息
        goPerfectingPersonalInformation(){
            this.$router.push('/perfectingPersonalInformation');
        },
        // 就诊报到
        goReportToTheDoctorList(){
            this.$router.push('/reportToTheDoctorList');
        },
        // 预约检查
        goListToBeChecked(){
            this.$router.push('/listToBeChecked');
        },
        // 待打印报告列表
        goListOfReportsToBePrinted(){
            this.$router.push('/listOfReportsToBePrinted');
        },
        // 待打印清单列表
        goListToBePrinted(){
            this.$router.push('/listToBePrinted');
        },
        // 充值查询
        goRechargeQuery(){
            this.$router.push('/rechargeQuery');   
        },
        set(){
            let total = this.total;
            let that = this;
            let timer = setInterval(function(){
                let currentRate = that.currentRate;
                let currentTime = that.currentTime;
                currentTime++;
                currentRate = currentTime / total * 100;
                currentRate = parseInt(currentRate);
                that.currentTime = currentTime;
                that.currentRate = currentRate;
                if(total==currentTime){
                    clearInterval(timer);
                    that.$router.push('/index');
                    return;
                }
            },1000)
            this.timer = timer;
        },
        getDate(){
            let myDate = new Date();
            let year = myDate.getFullYear();
            let month = myDate.getMonth() + 1;
            let date = myDate.getDate();
            let hour = myDate.getHours();
            let minute = myDate.getMinutes();
            let second = myDate.getSeconds();
            if(month<10){
                month = '0' + month;
            }
            if(date<10){
                date = '0' + date;
            }
            if(hour<10){
                hour = '0' + hour;
            }
            if(minute<10){
                minute = '0' + minute;
            }
            if(second<10){
                second = '0' + second;
            }
            let str = `${year}年${month}月${date}日 ${hour}:${minute}:${second}`;
            this.time = str;
        },
        // 获取当前时间
        getTime(){
            let timer2 = setInterval(()=>{
                this.getDate();
            },1000)
            this.timer2 = timer2;
        },
        login(){
            this.$log();
        },
        tuika(){
            this.$store.commit('tuika');
        }
    },
    beforeDestroy(){
        clearInterval(this.timer);
        clearInterval(this.timer2);
    }
}
</script>

<style scoped>
.van-circle >>> .van-circle__text{
    font-family: PingFangSC-Regular;
    font-size: 40px;
    font-weight: bold;
    color: #5D5D5D;
}
.content{
    display: flex;
    flex-wrap: wrap;
    margin: 0 auto;
    margin-top: 33px;
    width: 1109.76px;
}
.content .item{
    display: flex;
    flex-direction: column;
    width: 194.56px;
    height: 250.88px;
    background-color: #fff;
    box-shadow: 0 3px 9px 0 rgba(206,215,222,0.52);
    border-radius: 8px;
    align-items: center;
    justify-content: center;
    margin-right: 33.28px;
    margin-bottom: 29.696px;
    cursor: pointer;
}
.content .item:nth-child(5n){
    margin-right: 0;
}
.content .item img{
    width: 66px;
    height: 66px;
}
.content .item .name{
    font-family: PingFangSC-Regular;
    font-size: 30px;
    color: #5D5D5D;
    margin-top: 17.408px;
    font-weight: bold;
}
.content .item .subTitle{
    font-family: PingFangSC-Regular;
    font-size: 24px;
    color: #5D5D5D;
    margin-top: 5px;
}
.mt{
    margin-bottom: 0!important;
}
.content .item2{
    width: 422.4px!important;
    height: 250.88px!important;
    margin: 0;
}

.van-popup{
    overflow: visible;
}
.dialog{
    width: 600px;
    height: 300px;
    display: flex;
    flex-direction: column;
    justify-content: space-around;
    position: relative;
}
.dialog .top{
    font-family: PingFangSC-Regular;
    font-size: 30px;
    color: #000;
    text-align: center;
}
.dialog .bot{
    display: flex;
    justify-content: space-around;
}
.dialog .bot .btn{
    font-family: PingFangSC-Regular;
    font-size: 30px;
    font-weight: bold;
    color: #5D5D5D;
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: space-around;
    height: 150px;
    cursor: pointer;
}
.dialog .bot .btn img{
    width: 100px;
    height: 100px;
    border-radius: 50%;
}
.dialog .close{
    width: 50px;
    height: 50px;
    font-family: PingFangSC-Regular;
    font-size: 26px;
    border-radius: 50%;
    display: flex;
    align-items: center;
    justify-content: center;
    position: absolute;
    top: -25px;
    right: -25px;
    background-color: #fff;
    font-weight: bold;
    cursor: pointer;
}
</style>