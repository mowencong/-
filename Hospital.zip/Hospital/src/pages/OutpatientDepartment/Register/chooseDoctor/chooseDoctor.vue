<template>
    <div>
        <div class="header">
            <img src="../../../../assets/img/logo.png" alt="">

            <div class="detail"  v-if="this.$store.state.login">
                <div class="countDown">
                    <van-circle
                        v-model="currentRate"
                        :rate="rate"
                        :speed="100"
                        :text="text"
                        :stroke-width="100"
                        color="#5D5D5D"
                    />
                </div>
                <div class="info">
                    <div class="tui">
                        <div class="name">赵敏</div>

                        <div class="tuika" @click="tuika">
                            <div>退卡</div>
                        </div>
                    </div>
                    <div class="time">
                        {{time}}
                    </div>
                </div>
            </div>

            <div class="tuika" @click="login" style="margin-right:50px;" v-if="!this.$store.state.login">
                <div>登录</div>
            </div>
        </div>
        
        <top :title="title" :isHome='isHome'></top>

        <div class="content">
            <div class="timeGroup">
                <el-row :gutter="20">
                    <el-col :span="3">
                        <div class="item" :class="[index==0? 'active':'']" @click="chooseDate(0)">
                            <div>今天</div>
                        </div>
                        <div class="xian" v-show="index==0"></div>
                    </el-col>
                    <el-col :span="3">
                        <div class="item"  :class="[index==1? 'active':'']" @click="chooseDate(1)">
                            <div>03月12日</div>
                        </div>
                        <div class="xian" v-show="index==1"></div>
                    </el-col>
                    <el-col :span="3">
                        <div class="item"  :class="[index==2? 'active':'']" @click="chooseDate(2)">
                            <div>03月12日</div>
                        </div>
                        <div class="xian" v-show="index==2"></div>
                    </el-col>
                    <el-col :span="3">
                        <div class="item" :class="[index==3? 'active':'']" @click="chooseDate(3)">
                            <div>03月12日</div>
                        </div>
                        <div class="xian" v-show="index==3"></div>
                    </el-col>
                    <el-col :span="3">
                        <div class="item" :class="[index==4? 'active':'']" @click="chooseDate(4)">
                            <div>03月12日</div>
                        </div>
                        <div class="xian" v-show="index==4"></div>
                    </el-col>
                    <el-col :span="3">
                        <div class="item"  :class="[index==5? 'active':'']" @click="chooseDate(5)">
                            <div>03月12日</div>
                        </div>
                        <div class="xian" v-show="index==5"></div>
                    </el-col>
                    <el-col :span="3">
                        <div class="item"  :class="[index==6? 'active':'']" @click="chooseDate(6)">
                            <div>03月12日</div>
                        </div>
                        <div class="xian" v-show="index==6"></div>
                    </el-col>
                    <el-col :span="3">
                        <div class="item" :class="[index==7? 'active':'']" @click="chooseDate(7)">
                            <div>03月12日</div>
                        </div>
                        <div class="xian" v-show="index==7"></div>
                    </el-col>
                </el-row>
            </div>

            <div class="mid">
                <div class="item" :class="[act? 'active':'']" @click="chooseTime">上午</div>
                <div class="item" :class="[act? '':'active']" @click="chooseTime">下午</div>
            </div>

            <div class="cal">
                <el-carousel :autoplay="false" indicator-position="none" arrow="always" :loop="false">
                    <el-carousel-item v-for="item in 4" :key="item">
                        <div class="con">
                            <van-row :gutter="20">
                                <van-col :span="8">
                                    <div class="item" @click="go">
                                        <div class="name">马晓玲</div>
                                        <div class="type">普通门诊（6元）</div>
                                        <div class="amount">剩余 <span>40</span> 号</div>
                                    </div>
                                </van-col>
                                <van-col :span="8">
                                    <div class="item" @click="go">
                                        <div class="name">马晓玲</div>
                                        <div class="type">普通门诊（6元）</div>
                                        <div class="amount">剩余 <span>40</span> 号</div>
                                    </div>
                                </van-col>
                                <van-col :span="8">
                                    <div class="item" @click="go">
                                        <div class="name">马晓玲</div>
                                        <div class="type">普通门诊（6元）</div>
                                        <div class="amount">剩余 <span>40</span> 号</div>
                                    </div>
                                </van-col>
                                <van-col :span="8">
                                    <div class="item" @click="go">
                                        <div class="name">马晓玲</div>
                                        <div class="type">普通门诊（6元）</div>
                                        <div class="amount">剩余 <span>40</span> 号</div>
                                    </div>
                                </van-col>
                                <van-col :span="8">
                                    <div class="item" @click="go">
                                        <div class="name">马晓玲</div>
                                        <div class="type">普通门诊（6元）</div>
                                        <div class="amount">剩余 <span>40</span> 号</div>
                                    </div>
                                </van-col>
                                <van-col :span="8">
                                    <div class="item" @click="go">
                                        <div class="name">马晓玲</div>
                                        <div class="type">普通门诊（6元）</div>
                                        <div class="amount">剩余 <span>40</span> 号</div>
                                    </div>
                                </van-col>
                            </van-row>
                            
                        </div>
                    </el-carousel-item>
                </el-carousel>
            </div>
        </div>
    </div>
</template>

<script>
import head from '../../../../components/head'
export default {
    data(){
        return{
            title:'自助挂号-请选择医生',
            isHome:false,
            currentRate: 0,
            currentTime:0,
            rate:0,
            total:120,
            timer:null,
            timer2:null,
            time:'',
            index:0,
            act:true
        }
    },
    components:{
        'top':head
    },
    computed: {
        text() {
            return this.currentTime.toFixed(0) + 's'
        }
    },
    created(){
        this.getDate();
        this.getTime();
    },
    mounted(){
        // this.set();
    },
    methods:{
        go(){
            this.$router.push('/chooseTime');
        },
        chooseDate(index){
            console.log(index);
            this.index = index
        },
        chooseTime(){
            let ac = this.act;
            this.act = !ac
        },
        set(){
            let total = this.total;
            let that = this;
            let timer = setInterval(function(){
                let currentRate = that.currentRate;
                let currentTime = that.currentTime;
                currentTime++;
                currentRate = currentTime / total * 100;
                currentRate = parseInt(currentRate);
                that.currentTime = currentTime;
                that.currentRate = currentRate;
                if(total==currentTime){
                    this.$store.commit('down');
                    clearInterval(timer);
                    that.$router.push('/index');
                    return;
                }
                
            },1000)
            this.timer = timer;
        },
        getDate(){
            let myDate = new Date();
            let year = myDate.getFullYear();
            let month = myDate.getMonth() + 1;
            let date = myDate.getDate();
            let hour = myDate.getHours();
            let minute = myDate.getMinutes();
            let second = myDate.getSeconds();
            if(month<10){
                month = '0' + month;
            }
            if(date<10){
                date = '0' + date;
            }
            if(hour<10){
                hour = '0' + hour;
            }
            if(minute<10){
                minute = '0' + minute;
            }
            if(second<10){
                second = '0' + second;
            }
            let str = `${year}年${month}月${date}日 ${hour}:${minute}:${second}`;
            this.time = str;
        },
        // 获取当前时间
        getTime(){
            let timer2 = setInterval(()=>{
                this.getDate();
            },1000)
            this.timer2 = timer2;
        },
        login(){
            this.$log();
        },
        tuika(){
            this.$store.commit('tuika');
        }
    },
    beforeDestroy(){
        clearInterval(this.timer);
        clearInterval(this.timer2);
    }
}
</script>

<style scoped>
.countDown{
    margin-right: 30px;
}
.van-circle >>> .van-circle__text{
    font-family: PingFangSC-Regular;
    font-size: 40px;
    font-weight: bold;
    color: #5D5D5D;
}
.content{
    background: #EBF6F5;
    height: 529.41px;
    margin: 0 auto;
    width: 1109.76px;
    margin-top: 33px;
    border: 1px solid transparent;
}
.timeGroup{
    margin: 20px auto;
    width: 90%;
}
.timeGroup .item{
    width: 99.84px;
    height: 30px;
    display: flex;
    justify-content: center;
    cursor: pointer;
}
.timeGroup .active{
    color: #3FC7C5!important;
}
.timeGroup .item div{
    text-align: center;
    font-family: PingFangSC-Medium;
    font-size: 20px;
    color: #919191;
    font-weight: bold;
}
.timeGroup .active div{
    color: #3FC7C5!important;
}
.timeGroup .xian{
    width: 99.84px;
    height: 4px;
    background: #3FC7C5;
    border-radius: 4px;
}

.mid{
    width: 500px;
    height: 50px;
    margin: 20px auto;
    display: flex;
    justify-content: space-between;
}
.mid .item{
    width: 200px;
    display: flex;
    justify-content: center;
    align-items: center;
    font-family: PingFangSC-Regular;
    font-size: 30px;
    font-weight: bold;
    color: #3FC7C5;
    cursor: pointer;
    border: 1px solid #3FC7C5;
    border-radius: 4px;
}
.mid .item.active{
    color: #fff!important;
    background: #3FC7C5;
}

.cal{
    height: 360px;
}
.cal .el-carousel{
    height: 100%;
}
.cal .el-carousel >>> .el-carousel__container{
    height: 100%;
}
.cal .el-carousel >>> .el-carousel__arrow{
    background-color: transparent;
    color: #3FC7C5;
    font-size: 70px;
    font-weight: bold;
    top: 38%;
}
.cal .el-carousel >>> .el-carousel__arrow--left{
    left: 0;
}
.cal .el-carousel >>> .el-carousel__arrow--right{
    right: 42px;
}

.cal .con{
    display: flex;
    align-items: center;
    justify-content: center;
    height: 100%;
}
.cal .con .van-row{
    margin: 0 auto!important ;
    width: 90%;
}
.cal .con .van-row .van-col{
    margin-bottom: 30px;
}
.cal .con .van-row .item{
    width: 267.52px;
    height: 130px;
    background: #FFFFFF;
    box-shadow: 0 3px 9px 0 rgba(206,215,222,0.52);
    border-radius: 8px;
    display: flex;
    flex-direction: column;
    justify-content: space-around;
    margin: 0 auto;
    cursor: pointer;
}
.cal .con .van-row .item .name{
    font-family: PingFangSC-Semibold;
    font-size: 30px;
    font-weight: bold;
    color: #00958D;
    margin-left: 20px;
}
.cal .con .van-row .item .type{
    opacity: 0.7;
    font-family: PingFangSC-Regular;
    font-size: 20px;
    font-weight: bold;
    color: #5D5D5D;
    margin-left: 20px;
}
.cal .con .van-row .item .amount{
    font-family: PingFangSC-Regular;
    font-size: 20px;
    font-weight: bold;
    color: #9D9E9E;
    margin-left: 20px;
}
.cal .con .van-row .item .amount span{
    color: #FF8648;
}
</style>