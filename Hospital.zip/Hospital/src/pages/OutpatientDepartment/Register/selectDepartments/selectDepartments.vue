<template>
    <div>
        <div class="header">
            <img src="../../../../assets/img/logo.png" alt="">

            <div class="detail"  v-if="this.$store.state.login">
                <div class="countDown">
                    <van-circle
                        v-model="currentRate"
                        :rate="rate"
                        :speed="100"
                        :text="text"
                        :stroke-width="100"
                        color="#5D5D5D"
                    />
                </div>
                <div class="info">
                    <div class="tui">
                        <div class="name">赵敏</div>

                        <div class="tuika" @click="tuika">
                            <div>退卡</div>
                        </div>
                    </div>
                    <div class="time">
                        {{time}}
                    </div>
                </div>
            </div>

            <div class="tuika" @click="login" style="margin-right:50px;" v-if="!this.$store.state.login">
                <div>登录</div>
            </div>
        </div>
        <top :title="title" :isHome='isHome'></top>
        <div class="content">
            <div class="cc">
                <van-row style="width:100%;margin:0 auto;margin-top:33px;" :gutter="20">
                    <van-col :span="6">
                        <div class="item" @click="go">
                            <div class="name">接诊卡</div>
                        </div>
                    </van-col>
                    <van-col :span="6">
                        <div class="item" @click="go">
                            <div class="name">接诊卡</div>
                        </div>
                    </van-col>
                    <van-col :span="6">
                        <div class="item" @click="go">
                            <div class="name">接诊卡</div>
                        </div>
                    </van-col>
                    <van-col :span="6">
                        <div class="item" @click="go">
                            <div class="name">接诊卡</div>
                        </div>
                    </van-col>
                    <van-col :span="6">
                        <div class="item" @click="go">
                            <div class="name">接诊卡</div>
                        </div>
                    </van-col>
                    <van-col :span="6">
                        <div class="item" @click="go">
                            <div class="name">接诊卡</div>
                        </div>
                    </van-col>
                    <van-col :span="6">
                        <div class="item" @click="go">
                            <div class="name">接诊卡</div>
                        </div>
                    </van-col>
                    <van-col :span="6">
                        <div class="item" @click="go">
                            <div class="name">接诊卡</div>
                        </div>
                    </van-col>
                    <van-col :span="6">
                        <div class="item" @click="go">
                            <div class="name">接诊卡</div>
                        </div>
                    </van-col>
                    <van-col :span="6">
                        <div class="item" @click="go">
                            <div class="name">接诊卡</div>
                        </div>
                    </van-col>
                    <van-col :span="6">
                        <div class="item" @click="go">
                            <div class="name">接诊卡</div>
                        </div>
                    </van-col>
                </van-row>
            </div>
            <div class="bot">
                <van-pagination 
                v-model="currentPage" 
                :page-count="12"
                mode="simple" 
                />
            </div>
        </div>
    </div>
</template>

<script>
import head from '../../../../components/head'
export default {
    data(){
        return{
            title:'自助挂号-请选择科室',
            isHome:false,
            currentPage:1,
            currentRate: 0,
            currentTime:0,
            rate:0,
            total:120,
            timer:null,
            timer2:null,
            time:''
        }
    },
    components:{
        'top':head
    },
    computed: {
        text() {
            return this.currentTime.toFixed(0) + 's'
        }
    },
    created(){
        this.getDate();
        this.getTime();
    },
    mounted(){
        // this.set();
    },
    methods:{
        go(){
            this.$router.push('/selectionOfSpecificDepartments');
        },
        set(){
            let total = this.total;
            let that = this;
            let timer = setInterval(function(){
                let currentRate = that.currentRate;
                let currentTime = that.currentTime;
                currentTime++;
                currentRate = currentTime / total * 100;
                currentRate = parseInt(currentRate);
                that.currentTime = currentTime;
                that.currentRate = currentRate;
                if(total==currentTime){
                    this.$store.commit('down');
                    clearInterval(timer);
                    that.$router.push('/index');
                    return;
                }
                
            },1000)
            this.timer = timer;
        },
        getDate(){
            let myDate = new Date();
            let year = myDate.getFullYear();
            let month = myDate.getMonth() + 1;
            let date = myDate.getDate();
            let hour = myDate.getHours();
            let minute = myDate.getMinutes();
            let second = myDate.getSeconds();
            if(month<10){
                month = '0' + month;
            }
            if(date<10){
                date = '0' + date;
            }
            if(hour<10){
                hour = '0' + hour;
            }
            if(minute<10){
                minute = '0' + minute;
            }
            if(second<10){
                second = '0' + second;
            }
            let str = `${year}年${month}月${date}日 ${hour}:${minute}:${second}`;
            this.time = str;
        },
        // 获取当前时间
        getTime(){
            let timer2 = setInterval(()=>{
                this.getDate();
            },1000)
            this.timer2 = timer2;
        },
        login(){
            this.$log();
        },
        tuika(){
            this.$store.commit('tuika');
        }
    },
    beforeDestroy(){
        clearInterval(this.timer);
        clearInterval(this.timer2);
    }
}
</script>

<style scoped>
.countDown{
    margin-right: 30px;
}
.van-circle >>> .van-circle__text{
    font-family: PingFangSC-Regular;
    font-size: 40px;
    color: #5D5D5D;
    font-weight: bold;
}
.content{
    background: #EBF6F5;
    height: 529.41px;
    margin: 0 auto;
    width: 1109.76px;
    margin-top: 33px;
    border: 1px solid transparent;
    display: flex;
    flex-direction: column;
}
.cc{
    width: 90%;
    height: 352.26px;
    margin: 33px auto;
    display: block;
    margin-bottom: 0;
}
.van-col{
    margin-bottom: 30px;
}
.content .item{
    width: 100%;
    height: 62.46px;
    background: #3FC7C5;
    border: 1px solid #2EBAB8;
    border-radius: 4px;
    display: flex;
    align-items: center;
    justify-content: center;
    cursor: pointer;
}
.content .item .name{
    font-family: PingFangSC-Medium;
    font-size: 30px;
    color: #FFFFFF;
    font-weight: bold;
}
.bot{
    width: 100%;
    margin-top: 20px;
    border-top: 1px solid #DBDBDB;
    flex: 1;
    display: flex;
    align-items: center;
    justify-content: center;
}
.van-pagination{
    width: 60%;
}
.van-pagination >>> .van-pagination__item{
    width: 195.84px;
    height: 52px;
    display: flex;
    align-items: center;
    justify-content: center;
    font-family: PingFangSC-Medium;
    font-size: 30px;
    color: #3FC7C5;
    /* border: 2px solid #3FC7C5; */
    border-radius: 8px;
    font-weight: bold;
    cursor: pointer;
    background-color: #fff !important;
}
.van-pagination >>> .van-pagination__page-desc{
    height: 52px;
    line-height: 52px;
    font-family: PingFangSC-Medium;
    font-size: 30px;
    font-weight: bold;
}
.bot .page{
    width: 100%;
    height: 50px;
    font-family: PingFangSC-Medium;
    font-size: 18px;
    color: #919191;
    display: flex;
    align-items: center;
    margin-left: 60px;
}
.bot .control{
    display: flex;
    align-items: center;
    justify-content: center;
}
.bot .control .button{
    width: 195.84px;
    height: 52px;
    display: flex;
    align-items: center;
    justify-content: center;
    font-family: PingFangSC-Medium;
    font-size: 26px;
    color: #3FC7C5;
    border: 2px solid #3FC7C5;
    border-radius: 8px;
    font-weight: bold;
    cursor: pointer;
}
.bot .control .button:nth-child(1){
    margin-right: 30px;
}
</style>