<template>
    <div>
        <div class="header">
            <img src="../../../../assets/img/logo.png" alt="">
            
            <div class="detail"  v-if="this.$store.state.login">
                <div class="countDown">
                    <van-circle
                        v-model="currentRate"
                        :rate="rate"
                        :speed="100"
                        :text="text"
                        :stroke-width="100"
                        color="#5D5D5D"
                    />
                </div>
                <div class="info">
                    <div class="tui">
                        <div class="name">赵敏</div>

                        <div class="tuika" @click="tuika">
                            <div>退卡</div>
                        </div>
                    </div>
                    <div class="time">
                        {{time}}
                    </div>
                </div>
            </div>

            <div class="tuika" @click="login" style="margin-right:50px;" v-if="!this.$store.state.login">
                <div>登录</div>
            </div>
        </div>
        <top :title="title" :isHome='isHome'></top>
        <div class="content">
            <div class="cc">
                为改善门诊服务，我院已实行门诊流程改造，以下信息非常重要，请您仔细阅读：<br>
                &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;1、预约成功后不扣费，您需凭电子预约单到诊区报到后，方能就诊。<br>
                &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;2、请您在规定时间内到医院报到，报到地点：就诊区的微信迷你机、诊区护士及自助机。<br>
                &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;3、如因您自身原因，一个月内预约后出现爽约或迟到3次者，系统将自动暂停您的预约功能30天，届时，您将只能挂当天的门诊号，不能预约其他日期的门诊号。
                就诊后请您及时缴清费用（微信、线上缴费更方便），以免影响再次就诊。
            </div>
            <div class="btn" @click="go">
                我已知晓
            </div>
        </div>
    </div>
</template>

<script>
import head from '../../../../components/head'
export default {
    data(){
        return{
            title:'自助挂号须知',
            isHome:false,
            currentRate: 0,
            currentTime:0,
            rate:0,
            total:120,
            timer:null,
            timer2:null,
            time:''
        }
    },
    components:{
        'top':head
    },
    computed: {
        text() {
            return this.currentTime.toFixed(0) + 's'
        }
    },
    created(){
        this.getDate();
        this.getTime();
    },
    mounted(){
        // this.set();
    },
    methods:{
        go(){
            this.$router.push('/selectDepartments');
        },
        set(){
            let total = this.total;
            let that = this;
            let timer = setInterval(function(){
                let currentRate = that.currentRate;
                let currentTime = that.currentTime;
                currentTime++;
                currentRate = currentTime / total * 100;
                currentRate = parseInt(currentRate);
                that.currentTime = currentTime;
                that.currentRate = currentRate;
                if(total==currentTime){
                    this.$store.commit('down');
                    clearInterval(timer);
                    that.$router.push('/index');
                    return;
                }
                
            },1000)
            this.timer = timer;
        },
        getDate(){
            let myDate = new Date();
            let year = myDate.getFullYear();
            let month = myDate.getMonth() + 1;
            let date = myDate.getDate();
            let hour = myDate.getHours();
            let minute = myDate.getMinutes();
            let second = myDate.getSeconds();
            if(month<10){
                month = '0' + month;
            }
            if(date<10){
                date = '0' + date;
            }
            if(hour<10){
                hour = '0' + hour;
            }
            if(minute<10){
                minute = '0' + minute;
            }
            if(second<10){
                second = '0' + second;
            }
            let str = `${year}年${month}月${date}日 ${hour}:${minute}:${second}`;
            this.time = str;
        },
        // 获取当前时间
        getTime(){
            let timer2 = setInterval(()=>{
                this.getDate();
            },1000)
            this.timer2 = timer2;
        },
        login(){
            this.$log();
        },
        tuika(){
            this.$store.commit('tuika');
        }
    },
    beforeDestroy(){
        clearInterval(this.timer);
        clearInterval(this.timer2);
    }
}
</script>

<style scoped>
.van-circle >>> .van-circle__text{
    font-family: PingFangSC-Regular;
    font-size: 40px;
    font-weight: bold;
    color: #5D5D5D;
}
.content{
    background: #EBF6F5;
    height: 529.41px;
    margin: 0 auto;
    width: 1109.76px;
    margin-top: 33px;
    box-sizing: border-box;
    padding: 28px 38px;
    position: relative;
}
.cc{
    font-family: PingFangSC-Regular;
    font-size: 24px;
    color: #5D5D5D;
    line-height: 50px;
}
.btn{
    width: 194.56px;
    height: 58.37px;
    display: flex;
    align-items: center;
    justify-content: center;
    background: #3FC7C5;
    border-radius: 8px;
    font-family: PingFangSC-Regular;
    font-size: 30px;
    font-weight: bold;
    color: #FFFFFF;
    position: absolute;
    bottom: 128px;
    right: 60px;
    cursor: pointer;
}
</style>