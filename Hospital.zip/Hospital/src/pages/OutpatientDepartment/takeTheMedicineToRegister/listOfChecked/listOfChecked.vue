<template>
    <div>
        <div class="header">
            <img src="../../../../assets/img/logo.png" alt="">

            <div class="detail"  v-if="this.$store.state.login">
                <div class="countDown">
                    <van-circle
                        v-model="currentRate"
                        :rate="rate"
                        :speed="100"
                        :text="text"
                        :stroke-width="100"
                        color="#5D5D5D"
                    />
                </div>
                <div class="info">
                    <div class="tui">
                        <div class="name">赵敏</div>

                        <div class="tuika" @click="tuika">
                            <div>退卡</div>
                        </div>
                    </div>
                    <div class="time">
                        {{time}}
                    </div>
                </div>
            </div>

            <div class="tuika" @click="login" style="margin-right:50px;" v-if="!this.$store.state.login">
                <div>登录</div>
            </div>
        </div>
        
        <top :title="title" :isHome='isHome'></top>

        <div class="content">
            <div class="top">
                <van-row>
                    <van-col :span="4">
                        <div>就诊日期</div>
                    </van-col>
                    <van-col :span="4">
                        <div>科室</div>
                    </van-col>
                    <van-col :span="4">
                        <div>就诊医生</div>
                    </van-col>
                    <van-col :span="4">
                        <div>挂号类型</div>
                    </van-col>
                    <van-col :span="4">
                        <div>处方编号</div>
                    </van-col>
                    <van-col :span="4">
                        <div>取药报到</div>
                    </van-col>
                </van-row>
            </div>
            <div class="bot">
                <van-row v-for="item in tabledate" :key="item.id">
                    <van-col :span="4">
                        <div>{{item.time}}</div>
                    </van-col>
                    <van-col :span="4">
                        <div>{{item.Department}}</div>
                    </van-col>
                    <van-col :span="4">
                        <div>{{item.doctor}}</div>
                    </van-col>
                    <van-col :span="4">
                        <div>{{item.type}}</div>
                    </van-col>
                    <van-col :span="4">
                        <div>{{item.spu}}</div>
                    </van-col>
                    <van-col :span="4">
                        <div class="btn" v-if="item.expireDate < 60 *24" @click="go">我要报到</div>
                        <div class="btn2" v-else><div>已超日期</div><div class="dy" @click="go1">打印凭条</div></div>
                    </van-col>
                </van-row>
            </div>

            <div class="note">
                温馨提示：超过规定时间未取药的订单请到窗口退费。
            </div>
        </div>
    </div>
</template>

<script>
import head from '../../../../components/head'
export default {
    data(){
        return{
            title:'待报到列表-请核对账单明细',
            isHome:false,
            show:true,
            currentRate: 0,
            currentTime:0,
            rate:0,
            total:120,
            timer:null,
            timer2:null,
            time:'',
            //报道数组
            tabledate:[
                {
                    time:'2019年10月30日',
                    time1:'2019年10月30日',
                    Department:'呼吸内科',
                    doctor:'马小玲',
                    type:'普通门诊',
                    spu:'000001'
                },
                {
                    time:'2019年10月26日',
                    time1:'2019年10月26日',
                    Department:'骨科',
                    doctor:'马灵玲',
                    type:'普通门诊',
                    spu:'000002'
                },
                {
                    time:'2019年05月25日',
                    time1:'2019年05月25日',
                    Department:'儿科',
                    doctor:'马笑玲',
                    type:'普通门诊',
                    spu:'000003'
                },
                {
                    time:'2019年06月11日',
                    time1:'2019年06月11日',
                    Department:'妇科',
                    doctor:'黄志峰',
                    type:'普通门诊',
                    spu:'000004'
                },
                {
                    time:'2019年06月26日',
                    time1:'2019年06月26日',
                    Department:'皮肤科',
                    doctor:'陈世峰',
                    type:'普通门诊',
                    spu:'000005'
                },
                {
                    time:'2019年07月11日',
                    time1:'2019年07月11日',
                    Department:'肠胃科',
                    doctor:'马小玲',
                    type:'普通门诊',
                    spu:'000006'
                },
            ],
            expireDate:'',//过期时间
            report:true,
            expire:true
        }
    },
    components:{
        'top':head
    },
    computed: {
        text() {
            return this.currentTime.toFixed(0) + 's'
        }
    },
    created(){
        this.handleFree()
        this.getDate();
        this.getTime();
    },
    mounted(){
        // this.set();
        
    },
    methods:{
        go(){
            this.$router.push(`/reportDetail?report=${this.report}`);
        },
        go1(){
            this.$router.push(`/reportDetail?expire=${this.expire}`);
        },
        set(){
            let total = this.total;
            let that = this;
            let timer = setInterval(function(){
                let currentRate = that.currentRate;
                let currentTime = that.currentTime;
                currentTime++;
                currentRate = currentTime / total * 100;
                currentRate = parseInt(currentRate);
                that.currentTime = currentTime;
                that.currentRate = currentRate;
                if(total==currentTime){
                    this.$store.commit('down');
                    clearInterval(timer);
                    that.$router.push('/index');
                    return;
                }
                
            },1000)
            this.timer = timer;
        },
        //时间差判断报道是否失效
        handleFree(){
            //获取当前时间戳
            const timestamp = new Date().getTime()
            // console.log('111',timestamp)
            this.tabledate.map((t,index)=>{
                t.time1 = t.time1.replace(/年/,'-')
                t.time1 = t.time1.replace(/月/,'-')
                t.time1 = t.time1.replace(/日/,'')
                var date = new Date(t.time1)
                var date1 = date.getTime();
                //计算时间差
                this.tabledate[index].expireDate = (timestamp - date1)/1000/60
                // console.log('时间差',this.tabledate)
                return
            })
        },
        getDate(){
            let myDate = new Date();
            let year = myDate.getFullYear();
            let month = myDate.getMonth() + 1;
            let date = myDate.getDate();
            let hour = myDate.getHours();
            let minute = myDate.getMinutes();
            let second = myDate.getSeconds();
            if(month<10){
                month = '0' + month;
            }
            if(date<10){
                date = '0' + date;
            }
            if(hour<10){
                hour = '0' + hour;
            }
            if(minute<10){
                minute = '0' + minute;
            }
            if(second<10){
                second = '0' + second;
            }
            let str = `${year}年${month}月${date}日 ${hour}:${minute}:${second}`;
            this.time = str;
        },
        // 获取当前时间
        getTime(){
            let timer2 = setInterval(()=>{
                this.getDate();
            },1000)
            this.timer2 = timer2;
        },
        login(){
            this.$log();
        },
        tuika(){
            this.$store.commit('tuika');
        }
    },
    beforeDestroy(){
        clearInterval(this.timer);
    }
}
</script>

<style scoped>
.van-circle >>> .van-circle__text{
    font-family: PingFangSC-Regular;
    font-size: 24px;
    color: #5D5D5D;
}
.content{
    background: #EBF6F5;
    height: 529.41px;
    margin: 0 auto;
    width: 1109.76px;
    margin-top: 33px;
    border: 1px solid transparent;
    display: flex;
    flex-direction: column;
    position: relative;
}
.content .top{
    background-image: linear-gradient(230deg, #3FD1CF 3%, #06BDC3 100%);
    border-radius: 8px 8px 0 0;
    height: 78.85px;
    padding: 0 15px;
}
.content .top .van-row{
    height: 100%;
}
.content .top .van-row .van-col{
    height: 100%;
    display: flex;
    justify-content: center;
    align-items: center;
    opacity: 0.8;
    font-family: PingFangSC-Regular;
    font-size: 22px;
    color: #FFFFFF;
}

.content .bot{
    height: 340px;
    overflow-y: auto;
    background-color: #fff;
    padding: 0 15px;
}
.content .bot .van-row{
    border-bottom: 1px solid #eee;
}
.content .bot .van-row .van-col{
    display: flex;
    justify-content: center;
    align-items: center;
    height: 109.57px;
    font-family: PingFangSC-Semibold;
    font-size: 20px;
    color: #5E5E5E;
    font-weight: bold;
}

.content .note{
    width: 90%;
    height: 62px;
    background: #FFD5A3;
    border: 1px solid #F2B061;
    border-radius: 8px;
    font-family: PingFangSC-Medium;
    font-size: 26px;
    color: #CA8E47;
    display: flex;
    justify-content: center;
    align-items: center;
    position: absolute;
    bottom: 20px;
    left: 50%;
    margin-left: -45%;
}

.btn{
    width: 120px;
    height: 42px;
    display: flex;
    justify-content: center;
    align-items: center;
    border: 2px solid #3FC7C5;
    border-radius: 8px;
    color: #3FC7C5;
    cursor: pointer;
}
.btn2{
    width: 120px;
    height: 42px;
    display: flex;
    justify-content: center;
    align-items: center;
    border: 2px solid #D0D3D3;
    border-radius: 8px;
    color: #D0D3D3;
    cursor: pointer;
    flex-direction:column; 
}
.btn2 .dy{
    color:#8BC34A;
    font-size: 14px;
}
/*滚动条样式*/
.bot::-webkit-scrollbar {
    width: 4px;    
    /*height: 4px;*/
}
.bot::-webkit-scrollbar-thumb {
    border-radius: 10px;
    -webkit-box-shadow: inset 0 0 5px rgba(0,0,0,0.2);
    background: #C2C2C2;
}
.bot::-webkit-scrollbar-track {
    -webkit-box-shadow: inset 0 0 5px rgba(0,0,0,0.2);
    border-radius: 0;
    background: #E8E8E8;
}
</style>