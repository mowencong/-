<template>
    <div>
        <div class="header">
            <img src="../../../../assets/img/logo.png" alt="">

            <div class="detail"  v-if="this.$store.state.login">
                <div class="countDown">
                    <van-circle
                        v-model="currentRate"
                        :rate="rate"
                        :speed="100"
                        :text="text"
                        :stroke-width="100"
                        color="#5D5D5D"
                    />
                </div>
                <div class="info">
                    <div class="tui">
                        <div class="name">赵敏</div>

                        <div class="tuika" @click="tuika">
                            <div>退卡</div>
                        </div>
                    </div>
                    <div class="time">
                        {{time}}
                    </div>
                </div>
            </div>

            <div class="tuika" @click="login" style="margin-right:50px;" v-if="!this.$store.state.login">
                <div>登录</div>
            </div>
        </div>
        <top v-if="report1" :title="title" :isHome='isHome'></top>
        <top v-if="expire1" :title="title1" :isHome='isHome'></top>
        <div class="content">
            <div class="top">
                <van-row>
                    <van-col :span="8">
                        <div>药品名称</div>
                    </van-col>
                    <van-col :span="8">
                        <div>数量（盒）</div>
                    </van-col>
                    <van-col :span="8">
                        <div>单价（元）</div>
                    </van-col>
                </van-row>
            </div>
            <div class="bot">
                <van-row>
                    <van-col :span="8">
                        <div>盐酸氨氯地平</div>
                    </van-col>
                    <van-col :span="8">
                        <div>2</div>
                    </van-col>
                    <van-col :span="8">
                        <div>50.00元</div>
                    </van-col>
                </van-row>
                <van-row>
                    <van-col :span="8">
                        <div>二甲双胍片</div>
                    </van-col>
                    <van-col :span="8">
                        <div>2</div>
                    </van-col>
                    <van-col :span="8">
                        <div>10.00元</div>
                    </van-col>
                </van-row>
                <van-row>
                    <van-col :span="8">
                        <div>头孢丙烯颗粒</div>
                    </van-col>
                    <van-col :span="8">
                        <div>1</div>
                    </van-col>
                    <van-col :span="8">
                        <div>56.00元</div>
                    </van-col>
                </van-row>
               <van-row>
                    <van-col :span="8">
                        <div>二甲双胍片</div>
                    </van-col>
                    <van-col :span="8">
                        <div>2</div>
                    </van-col>
                    <van-col :span="8">
                        <div>10.00元</div>
                    </van-col>
                </van-row>
                <van-row>
                    <van-col :span="8">
                        <div>盐酸氨氯地平</div>
                    </van-col>
                    <van-col :span="8">
                        <div>2</div>
                    </van-col>
                    <van-col :span="8">
                        <div>50.00元</div>
                    </van-col>
                </van-row>
                <van-row>
                    <van-col :span="8">
                        <div>头孢丙烯颗粒</div>
                    </van-col>
                    <van-col :span="8">
                        <div>1</div>
                    </van-col>
                    <van-col :span="8">
                        <div>56.00元</div>
                    </van-col>
                </van-row>
            </div>

            <div class="btnG">
                <div class="title">
                    合计：650.00元
                </div>
                <div class="btn" @click="report">
                    <div v-if="report1">确认报道</div>
                    <div v-if="expire1">确认打印</div>
                </div>
            </div>
        </div>
        <!-- 报道成功弹框 -->
            <van-popup v-model="show">
                <div class="dialog">
                    <div class="head">
                        <div class="text" v-if="report1">
                            报道成功 <br>
                            请到取药窗口等候！
                        </div>
                        <div class="text" v-if="expire1">
                            打印成功 <br>
                            请取走您的凭条到取药窗口申请退费！
                        </div>
                        <div class="time">
                            （{{timing}}）S后自动关闭
                        </div>
                    </div>
                    <div class="mid">
                    </div>
                    <div class="bot" @click="popClose">
                        确定
                    </div>
                </div>
            </van-popup>
    </div>
</template>

<script>
import head from '../../../../components/head'
export default {
    data(){
        return{
            title:'待报道列表_请核对药品清单',
            title1:'超时未报道列表_请核对药品清单',
            isHome:false,
            currentRate: 0,
            currentTime:0,
            rate:0,
            total:120,
            timer:null,
            timer2:null,
            time:'',
            popTime:null,
            show:false, //报道状态
            report1:'',
            expire1:'',
            timing:3
        }
    },
    components:{
        'top':head
    },
    computed: {
        text() {
            return this.currentTime.toFixed(0) + 's'
        }
    },
    created(){
        this.getDate();
        this.getTime();
        this.expire1 = this.$route.query.expire
        this.report1 = this.$route.query.report
        // console.log('1111',this.expire1,this.report1)
    },
    mounted(){
        // this.set();
    },
    methods:{
        report(){
            this.show = true;
            var interval = setInterval(() =>{
                this.timing--
                if(this.timing == 0){
                    clearInterval(interval);
                }
            },1000)
            
            this.popTime = setTimeout(()=>{ 
                this.show = false;
                this.$router.push('/qutpatientHomePage');
            },3000)
        },
        set(){
            let total = this.total;
            let that = this;
            let timer = setInterval(function(){
                let currentRate = that.currentRate;
                let currentTime = that.currentTime;
                currentTime++;
                currentRate = currentTime / total * 100;
                currentRate = parseInt(currentRate);
                that.currentTime = currentTime;
                that.currentRate = currentRate;
                if(total==currentTime){
                    this.$store.commit('down');
                    clearInterval(timer);
                    that.$router.push('/index');
                    return;
                }
                
            },1000)
            this.timer = timer;
        },
        getDate(){
            let myDate = new Date();
            let year = myDate.getFullYear();
            let month = myDate.getMonth() + 1;
            let date = myDate.getDate();
            let hour = myDate.getHours();
            let minute = myDate.getMinutes();
            let second = myDate.getSeconds();
            if(month<10){
                month = '0' + month;
            }
            if(date<10){
                date = '0' + date;
            }
            if(hour<10){
                hour = '0' + hour;
            }
            if(minute<10){
                minute = '0' + minute;
            }
            if(second<10){
                second = '0' + second;
            }
            let str = `${year}年${month}月${date}日 ${hour}:${minute}:${second}`;
            this.time = str;
        },
        // 获取当前时间
        getTime(){
            let timer2 = setInterval(()=>{
                this.getDate();
            },1000)
            this.timer2 = timer2;
        },
        popClose(){
            this.show = false;
            clearTimeout(this.popTime);
            this.$router.push('/qutpatientHomePage');
        },
        login(){
            this.$log();
        },
        tuika(){
            this.$store.commit('tuika');
        }
    },
    beforeDestroy(){
        clearInterval(this.timer);
        clearInterval(this.timer2);
    }
}
</script>

<style scoped>
.countDown{
    margin-right: 30px;
}
.van-circle >>> .van-circle__text{
    font-family: PingFangSC-Regular;
    font-size: 40px;
    font-weight: bold;
    color: #5D5D5D;
}
.content{
    background: #EBF6F5;
    height: 529.41px;
    margin: 0 auto;
    width: 1109.76px;
    margin-top: 33px;
    border: 1px solid transparent;
    display: flex;
    flex-direction: column;
}
.content .top{
    background-image: linear-gradient(230deg, #3FD1CF 3%, #06BDC3 100%);
    border-radius: 8px 8px 0 0;
    height: 78.85px;
    padding: 0 15px;
}
.content .top .van-row{
    height: 100%;
}
.content .top .van-row .van-col{
    height: 100%;
    display: flex;
    justify-content: center;
    align-items: center;
    opacity: 0.8;
    font-family: PingFangSC-Regular;
    font-size: 22px;
    color: #FFFFFF;
}

.content .bot{
    height: 343px;
    overflow-y: scroll;
    background-color: #fff;
    padding: 0 15px;
}
.content .bot .van-row{
    border-bottom: 1px solid #eee;
}
.content .bot .van-row .van-col{
    display: flex;
    justify-content: center;
    align-items: center;
    height: 109.57px;
    font-family: PingFangSC-Semibold;
    font-size: 20px;
    color: #5E5E5E;
    font-weight: bold;
}

.btnG{
    width: 100%;
    flex: 1;
    display: flex;
    align-items: center;
    justify-content: space-between;
    padding: 0 30px;
    box-sizing: border-box;
}
.btnG .title{
    font-family: PingFangSC-Regular;
    font-size: 30px;
    font-weight: bold;
    color: #E51C23;
}
.btn{
    width: 156px;
    height: 44px;
    display: flex;
    justify-content: center;
    align-items: center;
    border: 2px solid #3FC7C5;
    background: #3FC7C5;
    font-family: PingFangSC-Regular;
    font-size: 30px;
    font-weight: bold;
    color: #FFFFFF;
    border-radius: 8px;
    cursor: pointer;
}

/*滚动条样式*/
.bot::-webkit-scrollbar {
    width: 4px;    
    /*height: 4px;*/
}
.bot::-webkit-scrollbar-thumb {
    border-radius: 10px;
    -webkit-box-shadow: inset 0 0 5px rgba(0,0,0,0.2);
    background: #C2C2C2;
}
.bot::-webkit-scrollbar-track {
    -webkit-box-shadow: inset 0 0 5px rgba(0,0,0,0.2);
    border-radius: 0;
    background: #E8E8E8;
}
.dialog{
    width: 600px;
    height: 300px;
    display: flex;
    flex-direction: column;
}
.dialog .head{
    display: flex;
    flex-direction: column;
    align-items: center;
    padding: 15px;
    height: 180px;
    justify-content: center;
}
.dialog .head .text{
    color: rgba(5, 145, 139, 0.8);
    font-size: 35px;
    text-align: center;
    font-family: SourceHanSansSC-regular;
}
.dialog .head .time{
    color: rgba(5, 145, 139, 0.8);
    font-size: 25px;
    text-align: center;
    font-family: SourceHanSansSC-regular;
    margin:  0 auto;
    margin-top: 15px;
}
.dialog .mid{
    width: 100%;
    height: 13px;
    background-color: rgba(5, 145, 139, 0.8);
}
.dialog .bot{
    display: flex;
    justify-content: center;
    align-items: center;
    flex: 1;
    color: rgba(5, 145, 139, 0.8);
    font-size: 35px;
    font-family: SourceHanSansSC-regular;
    cursor: pointer;
}
.dialog .bot div{
    width: 50%;
    text-align: center;
    height: 100%;
}
.dialog .bot div:nth-child(1){
    border-right: 1px solid rgba(5, 145, 139, 0.8);
}
</style>