<template>
    <div>
        <div class="header">
            <img src="../../../assets/img/logo.png" alt="">

            <div class="detail"  v-if="this.$store.state.login">
                <div class="countDown">
                    <van-circle
                        v-model="currentRate"
                        :rate="rate"
                        :speed="100"
                        :text="text"
                        :stroke-width="100"
                        color="#5D5D5D"
                    />
                </div>
                <div class="info">
                    <div class="tui">
                        <div class="name">赵敏</div>

                        <div class="tuika" @click="tuika">
                            <div>退卡</div>
                        </div>
                    </div>
                    <div class="time">
                        {{time}}
                    </div>
                </div>
            </div>

            <div class="tuika" @click="login" style="margin-right:50px;" v-if="!this.$store.state.login">
                <div>登录</div>
            </div>
        </div>
        
        <top :title="title" :isHome='isHome'></top>

        <div class="content">
            <div class="top">
                 <van-row>
                    <van-col :span="4">
                        <div>住院日期</div>
                    </van-col>
                    <van-col :span="4">
                        <div>患者性质</div>
                    </van-col>
                    <van-col :span="4">
                        <div>住院科室</div>
                    </van-col>
                    <van-col :span="4">
                        <div>住院床号</div>
                    </van-col>
                    <van-col :span="4">
                        <div>住院状态</div>
                    </van-col>
                    <van-col :span="4">
                        <div>每日清单</div>
                    </van-col>
                </van-row>
            </div>
            <div class="bot">
                <van-row>
                    <van-col :span="4">
                        <div>2018-03-06</div>
                    </van-col>
                    <van-col :span="4">
                        <div>异地医保</div>
                    </van-col>
                    <van-col :span="4">
                        <div>骨外科</div>
                    </van-col>
                    <van-col :span="4">
                        <div>3-21床</div>
                    </van-col>
                    <van-col :span="4">
                        <div>住院中</div>
                    </van-col>
                    <van-col :span="4">
                        <div class="btn" @click="go">我要查询</div>
                    </van-col>
                </van-row>
            </div>
        </div>
    </div>
</template>

<script>
import head from '../../../components/head'
export default {
    data(){
        return{
            title:'请选择住院列表',
            isHome:false,
            show:true,
            currentRate: 0,
            currentTime:0,
            rate:0,
            total:120,
            timer:null,
            timer2:null,
            time:'',
        }
    },
    components:{
        'top':head
    },
    computed: {
        text() {
            return this.currentTime.toFixed(0) + 's'
        }
    },
    created(){
        this.getDate();
        this.getTime();
    },
    mounted(){
        // this.set();
    },
    methods:{
        go(){
            this.$router.push('/checkHospitalizationInformation');
        },
        set(){
            let total = this.total;
            let that = this;
            let timer = setInterval(function(){
                let currentRate = that.currentRate;
                let currentTime = that.currentTime;
                currentTime++;
                currentRate = currentTime / total * 100;
                currentRate = parseInt(currentRate);
                that.currentTime = currentTime;
                that.currentRate = currentRate;
                if(total==currentTime){
                    this.$store.commit('down');
                    clearInterval(timer);
                    that.$router.push('/index');
                    return;
                }
                
            },1000)
            this.timer = timer;
        },
        getDate(){
            let myDate = new Date();
            let year = myDate.getFullYear();
            let month = myDate.getMonth() + 1;
            let date = myDate.getDate();
            let hour = myDate.getHours();
            let minute = myDate.getMinutes();
            let second = myDate.getSeconds();
            if(month<10){
                month = '0' + month;
            }
            if(date<10){
                date = '0' + date;
            }
            if(hour<10){
                hour = '0' + hour;
            }
            if(minute<10){
                minute = '0' + minute;
            }
            if(second<10){
                second = '0' + second;
            }
            let str = `${year}年${month}月${date}日 ${hour}:${minute}:${second}`;
            this.time = str;
        },
        // 获取当前时间
        getTime(){
            let timer2 = setInterval(()=>{
                this.getDate();
            },1000)
            this.timer2 = timer2;
        },
        login(){
            this.$log();
        },
        tuika(){
            this.$store.commit('tuika');
        }
    },
    beforeDestroy(){
        clearInterval(this.timer);
        clearInterval(this.timer2);
    }
}
</script>

<style scoped>
.countDown{
    margin-right: 30px;
}
.van-circle >>> .van-circle__text{
    font-family: PingFangSC-Regular;
    font-size: 40px;
    font-weight: bold;
    color: #5D5D5D;
}
.content{
    background: #EBF6F5;
    height: 529.41px;
    margin: 0 auto;
    width: 1109.76px;
    margin-top: 33px;
    border: 1px solid transparent;
    display: flex;
    flex-direction: column;
}
.content .top{
    background-image: linear-gradient(230deg, #3FD1CF 3%, #06BDC3 100%);
    border-radius: 8px 8px 0 0;
    height: 78.85px;
    padding: 0 15px;
}
.content .top .van-row{
    height: 100%;
}
.content .top .van-row .van-col{
    height: 100%;
    display: flex;
    justify-content: center;
    align-items: center;
    opacity: 0.8;
    font-family: PingFangSC-Regular;
    font-size: 22px;
    color: #FFFFFF;
}

.content .bot{
    flex: 1;
    overflow-y: auto;
    background-color: #fff;
    padding: 0 15px;
}
.content .bot .van-row{
    border-bottom: 1px solid #eee;
}
.content .bot .van-row .van-col{
    display: flex;
    justify-content: center;
    align-items: center;
    height: 109.57px;
    font-family: PingFangSC-Semibold;
    font-size: 20px;
    color: #5E5E5E;
    font-weight: bold;
}
.btn{
    width: 120px;
    height: 42px;
    display: flex;
    justify-content: center;
    align-items: center;
    border: 2px solid #3FC7C5;
    border-radius: 8px;
    color: #3FC7C5;
    cursor: pointer;
}
.btn2{
    width: 120px;
    height: 42px;
    display: flex;
    justify-content: center;
    align-items: center;
    border: 2px solid #D0D3D3;
    border-radius: 8px;
    color: #D0D3D3;
    cursor: pointer;
}

/*滚动条样式*/
.bot::-webkit-scrollbar {
    width: 4px;    
    /*height: 4px;*/
}
.bot::-webkit-scrollbar-thumb {
    border-radius: 10px;
    -webkit-box-shadow: inset 0 0 5px rgba(0,0,0,0.2);
    background: #C2C2C2;
}
.bot::-webkit-scrollbar-track {
    -webkit-box-shadow: inset 0 0 5px rgba(0,0,0,0.2);
    border-radius: 0;
    background: #E8E8E8;
}
</style>