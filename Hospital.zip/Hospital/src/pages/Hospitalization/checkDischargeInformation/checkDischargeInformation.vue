<template>
    <div>
        <div class="header">
            <img src="../../../assets/img/logo.png" alt="">

            <div class="detail"  v-if="this.$store.state.login">
                <div class="countDown">
                    <van-circle
                        v-model="currentRate"
                        :rate="rate"
                        :speed="100"
                        :text="text"
                        :stroke-width="100"
                        color="#5D5D5D"
                    />
                </div>
                <div class="info">
                    <div class="tui">
                        <div class="name">赵敏</div>

                        <div class="tuika" @click="tuika">
                            <div>退卡</div>
                        </div>
                    </div>
                    <div class="time">
                        {{time}}
                    </div>
                </div>
            </div>

            <div class="tuika" @click="login" style="margin-right:50px;" v-if="!this.$store.state.login">
                <div>登录</div>
            </div>
        </div>
        
        <top :title="title" :isHome='isHome'></top>

        <div class="content">
            <div class="item">
                <div class="title">患者姓名：</div>
                <div class="text">黄明政</div>
            </div>
            <div class="item">
                <div class="title">患者性质：</div>
                <div class="text">异地医保</div>
            </div>
            <div class="item">
                <div class="title">住院科室：</div>
                <div class="text">骨外科</div>
            </div>
            <div class="item">
                <div class="title">住院床号：</div>
                <div class="text">3-21床（住院部1号楼6层骨外科3-21床）</div>
            </div>
            <div class="item">
                <div class="title">办理时间：</div>
                <div class="text">2019年03月11日  上午 11:21:11</div>
            </div>
            <div class="item">
                <div class="title">押金余额：</div>
                <div class="text">1000.00元</div>
            </div>
            <div class="item">
                <div class="title">费用合计：</div>
                <div class="text">1000.00元</div>
            </div>
            <div class="item">
                <div class="title">应补缴费用：</div>
                <div class="price">1000.00元</div>
            </div>
            <div class="btn" @click="next">
                <div>确认办理</div>
            </div>
        </div>
    </div>
</template>

<script>
import head from '../../../components/head'
export default {
    data(){
        return{
            title:'入院登记列表-请核对住院信息',
            isHome:false,
            currentRate: 0,
            currentTime:0,
            rate:0,
            total:120,
            timer:null,
            timer2:null,
            time:'',
        }
    },
    components:{
        'top':head
    },
    computed: {
        text() {
            return this.currentTime.toFixed(0) + 's'
        }
    },
    created(){
        this.getDate();
        this.getTime();
    },
    mounted(){
        // this.set();
    },
    methods:{
        go(){
            this.$router.push('/chooseTime');
        },
        next(){
            this.$router.push('/choosePayType');
        },
        set(){
            let total = this.total;
            let that = this;
            let timer = setInterval(function(){
                let currentRate = that.currentRate;
                let currentTime = that.currentTime;
                currentTime++;
                currentRate = currentTime / total * 100;
                currentRate = parseInt(currentRate);
                that.currentTime = currentTime;
                that.currentRate = currentRate;
                if(total==currentTime){
                    this.$store.commit('down');
                    clearInterval(timer);
                    that.$router.push('/index');
                    return;
                }
                
            },1000)
            this.timer = timer;
        },
        getDate(){
            let myDate = new Date();
            let year = myDate.getFullYear();
            let month = myDate.getMonth() + 1;
            let date = myDate.getDate();
            let hour = myDate.getHours();
            let minute = myDate.getMinutes();
            let second = myDate.getSeconds();
            if(month<10){
                month = '0' + month;
            }
            if(date<10){
                date = '0' + date;
            }
            if(hour<10){
                hour = '0' + hour;
            }
            if(minute<10){
                minute = '0' + minute;
            }
            if(second<10){
                second = '0' + second;
            }
            let str = `${year}年${month}月${date}日 ${hour}:${minute}:${second}`;
            this.time = str;
        },
        // 获取当前时间
        getTime(){
            let timer2 = setInterval(()=>{
                this.getDate();
            },1000)
            this.timer2 = timer2;
        },
        login(){
            this.$log();
        },
        tuika(){
            this.$store.commit('tuika');
        }
    },
    beforeDestroy(){
        clearInterval(this.timer);
        clearInterval(this.timer2);
    }
}
</script>

<style scoped>
.countDown{
    margin-right: 30px;
}
.van-circle >>> .van-circle__text{
    font-family: PingFangSC-Regular;
    font-size: 40px;
    font-weight: bold;
    color: #5D5D5D;
}
.content{
    background: #EBF6F5;
    height: 529.41px;
    margin: 0 auto;
    width: 1109.76px;
    margin-top: 33px;
    border: 1px solid transparent;
    display: flex;
    flex-direction: column;
    justify-content: space-around;
    position: relative;
}
.item{
    display: flex;
    margin-left: 30px;
}
.item .title{
    opacity: 0.5;
    font-family: PingFangSC-Regular;
    font-size: 24px;
    color: #5E5E5E;
}
.item .text{
    font-family: PingFangSC-Semibold;
    font-size: 26px;
    color: #5E5E5E;
    font-weight: bold;
}
.item .price{
    font-family: PingFangSC-Semibold;
    font-size: 26px;
    color: #DA251C;
    font-weight: bold;
}
.btn{
    width: 194.56px;
    height: 58.37px;
    display: flex;
    align-items: center;
    justify-content: center;
    background: #3FC7C5;
    border-radius: 8px;
    font-family: PingFangSC-Regular;
    font-size: 26px;
    color: #FFFFFF;
    position: absolute;
    bottom: 20px;
    right: 30px;
}

.van-popup{
    overflow: visible;
    border-radius: 13px 13px 13px 13px;
    background-color: rgba(255, 255, 255, 0.8);
}
.dialog{
    width: 600px;
    height: 300px;
    display: flex;
    flex-direction: column;
}
.dialog .head{
    display: flex;
    flex-direction: column;
    align-items: center;
    padding: 15px;
}
.dialog .head .text{
    color: rgba(5, 145, 139, 0.8);
    font-size: 35px;
    text-align: center;
    font-family: SourceHanSansSC-regular;
}
.dialog .head .time{
    color: rgba(5, 145, 139, 0.8);
    font-size: 25px;
    text-align: center;
    font-family: SourceHanSansSC-regular;
    margin-top: 15px;
    margin-right: 5px;
}
.dialog .mid{
    width: 100%;
    height: 13px;
    background-color: rgba(5, 145, 139, 0.8);
}
.dialog .bot{
    display: flex;
    justify-content: center;
    align-items: center;
    flex: 1;
    color: rgba(5, 145, 139, 0.8);
    font-size: 35px;
    font-family: SourceHanSansSC-regular;
    cursor: pointer;
}
</style>