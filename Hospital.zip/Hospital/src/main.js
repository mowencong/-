import Vue from 'vue'
import App from './App.vue'
import router from './router'
import store from './store'
import ElementUI from 'element-ui';
import 'element-ui/lib/theme-chalk/index.css';
import Vant from 'vant';
import 'vant/lib/index.css';
import {get,post} from './components/api'

Vue.use(ElementUI);
Vue.use(Vant);


Vue.config.productionTip = false

Vue.prototype.$get = get

Vue.prototype.$post = post

Vue.prototype.$log = function(){
  router.push('/loginMode');
} 


//路由守卫
router.beforeEach((to, from, next)=>{
  if(to.meta.login == true){
    // console.log('1110',store.state);
    if(store.state.login==true){
      next()
    }else{
      next({path: '/loginMode'});
    }
  }else{
    next();
  }
  // next()
})

new Vue({
  router,
  store,
  render: h => h(App)
}).$mount('#app')
