import Vue from 'vue'
import Vuex from 'vuex'

Vue.use(Vuex)

export default new Vuex.Store({
  state: {
    login:false,
    tuika:false,
    timer:null
  },
  mutations: {
    login(state){
      state.login = true;
    },
    down(state){
      state.login = false;
    },
    tuika(state){
      state.tuika = true;
      state.login = false;
      state.timer = setTimeout(()=>{
        state.tuika = false
      },3000)
    },
    closePop(state){
      state.tuika = false;
      clearTimeout(state.timer);
    }
  },
  actions: {

  }
})
