import axios from 'axios'
// import vueAxios from 'vue-axios';
import qs from 'qs'

// 响应时间
axios.defaults.timeout = 5 * 1000
// 配置cookie
axios.defaults.withCredentials = false
// 配置请求头
axios.defaults.headers.post['Content-Type'] = 'application/x-www-form-urlencoded;charset=UTF-8'

// 取消重复请求
let pending = []; //声明一个数组用于存储每个ajax请求的取消函数和ajax标识
let cancelToken = axios.CancelToken;
let removePending = (config) => {
    for(let p in pending){
        if(pending[p].u === config.url + '&' + config.method) { //当当前请求在数组中存在时执行函数体
            pending[p].f(); //执行取消操作
            pending.splice(p, 1); //把这条记录从数组中移除
        }
    }
}


axios.interceptors.request.use(
    config => {
      // const token = localStorage.getItem('shopxToken');
      
      removePending(config); //在一个ajax发送前执行一下取消操作
      config.cancelToken = new cancelToken((c)=>{
          // 这里的ajax标识我是用请求地址&请求方式拼接的字符串，当然你可以选择其他的一些方式
          pending.push({ u: config.url + '&' + config.method, f: c });  
      });


      // TOKEN存在则默认加入请求头
      // if (token) {
      //   config.headers['token'] = token;
      // }
      if(config.method=='post'){
        config.data = qs.stringify(config.data);
      }
      return config;
    }
);


//添加响应拦截器
axios.interceptors.response.use(res=>{
  removePending(res.config);  //在一个ajax响应后再执行一下取消操作，把已经完成的请求从pending中移除
  return res;
},error =>{
        // 配置错误返回后的操作
        // if(err && err.response){
        //   switch(err.response.status){
        //     case 401:
        //         err.message = '未授权，请重新登录';
        //         break;
        //   }
        // }
        return Promise.reject(error);
});


// 配置接口地址
axios.defaults.baseURL = 'http://47.112.3.10:8281';

export default axios;

// 发送请求
export function post(url, params) {
  return new Promise((resolve, reject) => {
      axios({
        method: 'post',
          url:url,
          data: params,
          paramsSerializer: function (params) {
            return qs.stringify(params, {arrayFormat: 'repeat'})
          },
      }).then(
        res=>{
          resolve(res.data)
        },err=>{
          reject(err.data)
        }
      ).catch(err=>{
        reject(err.data)
      })
  })
}

export function get(url, params) {
  return new Promise((resolve, reject) => {
    axios
      .get(url, {
        params: params,
        paramsSerializer: function (params) {
          return qs.stringify(params, {arrayFormat: 'repeat'})
        },
      })
      .then(res => {
        resolve(res.data);
      })
      .catch(err => {
        reject(err.data);

      })
  })
}