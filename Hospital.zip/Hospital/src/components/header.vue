<template>
    <div class="header">
        <img src="../assets/img/logo.png" alt="">
        
        <div class="detail"  v-if="timeShow">
            <div class="countDown">
                <van-circle
                    v-model="currentRate"
                    :rate="rate"
                    :speed="100"
                    :text="text"
                    :stroke-width="100"
                    color="#5D5D5D"
                />
            </div>
            <div class="info">
                <div>
                    <div class="tui">
                        <div class="name">赵敏</div>
                    </div>
                </div>
                
                <div class="time">
                    {{time}}
                </div>
            </div>
        </div>
    </div>
</template>

<script>
export default {
    data(){
        return{
            timeShow:true,
            currentRate: 0,
            currentTime:0,
            rate:0,
            total:120,
            timer:null,
            timer2:null,
            time:''
        }
    },
    props(){
        
    },
    methods:{
        set(){
            let total = this.total;
            let that = this;
            let timer = setInterval(function(){
                let currentRate = that.currentRate;
                let currentTime = that.currentTime;
                currentTime++;
                currentRate = currentTime / total * 100;
                currentRate = parseInt(currentRate);
                that.currentTime = currentTime;
                that.currentRate = currentRate;
                if(total==currentTime){
                    clearInterval(timer);
                    return;
                }
            },1000)
            this.timer = timer;
        },
        getDate(){
            let myDate = new Date();
            let year = myDate.getFullYear();
            let month = myDate.getMonth() + 1;
            let date = myDate.getDate();
            let hour = myDate.getHours();
            let minute = myDate.getMinutes();
            let second = myDate.getSeconds();
            if(month<10){
                month = '0' + month;
            }
            if(date<10){
                date = '0' + date;
            }
            if(hour<10){
                hour = '0' + hour;
            }
            if(minute<10){
                minute = '0' + minute;
            }
            if(second<10){
                second = '0' + second;
            }
            let str = `${year}年${month}月${date}日 ${hour}:${minute}:${second}`;
            this.time = str;
        },
        // 获取当前时间
        getTime(){
            let timer2 = setInterval(()=>{
                this.getDate();
            },1000)
            this.timer2 = timer2;
        },
    }
}
</script>

<style scoped>
.header{
    width: 100%;
    height: 184.32px;
    background-color: rgba(147,207,206, 0.4);
    display: flex;
    align-items: center;
    justify-content: space-between;
}
.header img{
  width: 259.84px;
  height: 83.968px;
  margin-left: 83.2px;
}
.header .detail{
  display: flex;
  margin-right: 60px;
}
.header .detail .info{
  display: flex;
  flex-direction: column;
  align-items: center;
  width: 330px;
  height: 108px;
}
.header .detail .info .tui{
  width: 100%;
  display: flex;
  margin-bottom: 50px;
  height: 29px;
}
.header .detail .info .tui .name{
  font-family: PingFangSC-Regular;
  font-size: 30px;
  color: #000;
  font-weight: bold;
}
.header .detail .info .time{
  font-family: PingFangSC-Regular;
  font-size: 26px;
  color: #000;
  font-weight: bold;
}
</style>