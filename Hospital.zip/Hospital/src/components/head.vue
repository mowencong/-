<template>
    <div class="top">
        <div class="title">
            <div class="xian"></div>
            <span>{{title}}</span>
        </div>
        <div class="btnG">
            <div class="btn" v-show="!isHome" @click="goHome">
                <img src="../assets/img/home.png" alt="">
                <div>首页</div>
            </div>
            <div class="btn" v-show="!homePage" @click="back">
                <img src="../assets/img/back.png" alt="">
                <div>返回</div>
            </div>
            <!-- <div class="btn" v-show="isHome" @click="tui">
                <div>退卡</div>
            </div> -->
        </div>
        
        
        <!-- <van-popup v-model="show">
            <div class="dialog">
                <div class="head">
                    <div class="text">
                        &nbsp;&nbsp;退出成功,若使用卡片登录,<br>&nbsp;&nbsp;&nbsp;请取走您的卡片！
                    </div>
                    <div class="time">
                        （3）S后自动关闭
                    </div>
                </div>
                <div class="mid">

                </div>
                <div class="bot" @click="popClose">
                    确定
                </div>
            </div>
        </van-popup> -->
    </div>
</template>

<script>
export default {
    data(){
        return{
            show:false,
            popTime:null
        }
    },
    props:{
        title:{
            type:String,
            default:()=>{}
        },
        isHome:{
            type:Boolean,
            default:()=>{}
        },
        homePage:{
            type:Boolean,
            default:()=>{}
        }
    },
    methods:{
        goHome(){
            this.$router.push('/index');
        },
        back(){
            this.$router.go(-1);
        },
        tui(){
            this.show = true;
            this.popTime = setTimeout(()=>{
                this.show = false;
            },3000)
        },
        popClose(){
            this.show = false;
            clearTimeout(this.popTime);
        }
    }
}
</script>

<style scoped>
.top{
    display: flex;
    justify-content: space-between;
    margin: 0 auto;
    margin-top: 30px;
    align-items: center;
    height: 58px;
    width: 1109.76px;
}
.top .title{
    display: flex;
    align-items: center;
    font-family: PingFangSC-Medium;
    font-size: 26px;
    color: #00958D;
    font-weight: bold;
}
.top .title .xian{
    width: 4px;
    height: 35px;
    background: #00948C;
    border-radius: 3px;
    margin-right: 20.48px;
}
.btnG{
    display: flex;
}
.btn{
    width: 194.56px;
    height: 58px;
    display: flex;
    align-items: center;
    justify-content: center;
    background: #3FC7C5;
    box-shadow: 0 3px 9px 0 #C5D0D5;
    border-radius: 8px;
    font-family: PingFangSC-Regular;
    font-size: 30px;
    color: #FFFFFF;
    cursor: pointer;
    font-weight: bold;
}
.btn img{
    margin-right: 7.168px;
}
.btn:nth-child(2){
    margin-left: 26.624px;
}

.van-popup{
    overflow: visible;
    border-radius: 13px 13px 13px 13px;
    background-color: rgba(255, 255, 255, 0.8);
}
.dialog{
    width: 600px;
    height: 300px;
    display: flex;
    flex-direction: column;
}
.dialog .head{
    display: flex;
    flex-direction: column;
    align-items: center;
    padding: 15px;
}
.dialog .head .text{
    color: rgba(5, 145, 139, 0.8);
    font-size: 35px;
    text-align: center;
    font-family: SourceHanSansSC-regular;
}
.dialog .head .time{
    color: rgba(5, 145, 139, 0.8);
    font-size: 25px;
    text-align: center;
    font-family: SourceHanSansSC-regular;
    margin-top: 15px;
    margin-right: 5px;
}
.dialog .mid{
    width: 100%;
    height: 13px;
    background-color: rgba(5, 145, 139, 0.8);
}
.dialog .bot{
    display: flex;
    justify-content: center;
    align-items: center;
    flex: 1;
    color: rgba(5, 145, 139, 0.8);
    font-size: 35px;
    font-family: SourceHanSansSC-regular;
    cursor: pointer;
}
</style>