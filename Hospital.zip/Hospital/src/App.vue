<template>
  <div class="homeBg">
      <div class="contain">
        <router-view/>
      </div>
      <div class="foot">
        <img src="./assets/img/bankLogo.png" alt="">
        <div class="title">
          版本号：2019.05.14.v.1.0
        </div>
      </div>

      <van-popup v-model="this.$store.state.tuika">
            <div class="dialog">
                <div class="head">
                    <div class="text">
                        &nbsp;&nbsp;退出成功,若使用卡片登录,<br>&nbsp;&nbsp;&nbsp;请取走您的卡片！
                    </div>
                    <div class="time">
                        （3）S后自动关闭
                    </div>
                </div>
                <div class="mid">

                </div>
                <div class="bot" @click="close">
                    确定
                </div>
            </div>
        </van-popup>
  </div>
</template>

<script>
export default {
  data(){
    return{
      // currentRate: 0,
      // currentTime:0,
      // rate:0,
      // total:120,
      // timer:null,
      // timer2:null,
      // time:''
    }
  },
  computed: {
      // text() {
      //     return this.currentTime.toFixed(0) + 's'
      // }
  },
  created(){
    // this.getTime();
  },
  mounted(){
    // this.set();
  },
  methods:{
    close(){
      this.$store.commit('closePop');
    }
  }
}
</script>

<style>
*{
  margin: 0;
  padding: 0;
}
.van-circle >>> .van-circle__text{
    font-family: PingFangSC-Regular;
    font-size: 24px;
    color: #5D5D5D;
}
.homeBg{
    background: url('./assets/img/BG.png') no-repeat;
    background-size: 100% 100%;
    height: 100vh;
    display: flex;
    flex-direction: column;
}
.header{
    width: 100%;
    height: 184.32px;
    background-color: rgba(147,207,206, 0.4);
    display: flex;
    align-items: center;
    justify-content: space-between;
}
.header img{
  width: 259.84px;
  height: 83.968px;
  margin-left: 83.2px;
}
.header .detail{
  display: flex;
  margin-right: 60px;
}
.header .detail .info{
  display: flex;
  flex-direction: column;
  align-items: center;
  width: 330px;
  height: 108px;
}
.header .detail .info .tui{
  width: 100%;
  display: flex;
  margin-bottom: 20px;
  align-items: center;
  justify-content: space-between;
}
.header .detail .info .tui .name{
  font-family: PingFangSC-Regular;
  font-size: 30px;
  color: #000;
  font-weight: bold;
}
.header .detail .info .time{
  font-family: PingFangSC-Regular;
  font-size: 26px;
  color: #000;
  font-weight: bold;
}
.contain{
    flex: 1;
    width: 100%;
    margin: 0 auto;
}
.foot{
    height: 101.376px;
    background-color: rgba(187,225,224, 0.5);
    display: flex;
    align-items: center;
    justify-content: space-between;
}
.foot img{
  width: 290.56px;
  height: 58.368px;
  margin-left: 87.04px;
}
.foot .title{
  font-family: PingFangSC-Medium;
  font-size: 20px;
  color: #069C95;
  font-weight: bold;
  margin-right: 44.8px;
}
.countDown{
  margin-right: 30px;
}

.van-popup{
    overflow: visible;
    border-radius: 13px 13px 13px 13px;
    background-color: rgba(255, 255, 255, 0.8);
}
.dialog{
    width: 600px;
    height: 300px;
    display: flex;
    flex-direction: column;
    background-color: #D8D8D8;
}
.dialog .head{
    display: flex;
    flex-direction: column;
    align-items: center;
    padding: 15px;
    background-color: 
}
.dialog .head .text{
    color: rgba(5, 145, 139, 0.8);
    font-size: 35px;
    text-align: center;
    font-family: SourceHanSansSC-regular;
}
.dialog .head .time{
    color: rgba(5, 145, 139, 0.8);
    font-size: 25px;
    text-align: center;
    font-family: SourceHanSansSC-regular;
    margin-top: 15px;
    margin-right: 5px;
}
.dialog .mid{
    width: 100%;
    height: 13px;
    background-color: rgba(5, 145, 139, 0.8);
}
.dialog .bot{
    display: flex;
    justify-content: center;
    align-items: center;
    flex: 1;
    color: rgba(5, 145, 139, 0.8);
    font-size: 35px;
    font-family: SourceHanSansSC-regular;
    cursor: pointer;
}

.tuika{
    width: 194.56px;
    height: 58px;
    display: flex;
    align-items: center;
    justify-content: center;
    background: #3FC7C5;
    box-shadow: 0 3px 9px 0 #C5D0D5;
    border-radius: 8px;
    font-family: PingFangSC-Regular;
    font-size: 30px;
    color: #FFFFFF;
    cursor: pointer;
    font-weight: bold;
}
</style>
