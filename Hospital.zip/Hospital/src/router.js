import Vue from 'vue'
import Router from 'vue-router'


Vue.use(Router)

export default new Router({
  mode: 'history',
  base: process.env.BASE_URL,
  routes: [
    {
      path: '/',
      name: 'index',
      redirect:'/index'
    },
    // 医院首页
    {
      path: '/index',
      name: 'index',
      component: () => import(/* webpackChunkName: "about" */ './pages/index/index.vue')
    },


    // 登录方式
    {
      path: '/loginMode',
      name: 'loginMode',
      component: () => import(/* webpackChunkName: "about" */ './pages/Login/loginMode/loginMode.vue')
    },
    // 就诊卡登录
    {
      path: '/visitingCardLogin',
      name: 'visitingCardLogin',
      component: () => import(/* webpackChunkName: "about" */ './pages/Login/visitingCardLogin/visitingCardLogin.vue')
    },
    // 身份证登录
    {
      path: '/identityCardLogin',
      name: 'identityCardLogin',
      component: () => import(/* webpackChunkName: "about" */ './pages/Login/identityCardLogin/identityCardLogin.vue')
    },
    // 居民健康卡登录
    {
      path: '/residentHealthCardLogin',
      name: 'residentHealthCardLogin',
      component: () => import(/* webpackChunkName: "about" */ './pages/Login/residentHealthCardLogin/residentHealthCardLogin.vue')
    },
    // 社保卡登录
    {
      path: '/socialSecurityCardLogin',
      name: 'socialSecurityCardLogin',
      component: () => import(/* webpackChunkName: "about" */ './pages/Login/socialSecurityCardLogin/socialSecurityCardLogin.vue')
    },
    // 住院单号登录
    {
      path: '/hospitalizationlogin',
      name: 'hospitalizationlogin',
      component: () => import(/* webpackChunkName: "about" */ './pages/Login/hospitalizationlogin/hospitalizationlogin.vue')
    },
    // 核对登录信息
    {
      path: '/checkloginInformation',
      name: 'checkloginInformation',
      component: () => import(/* webpackChunkName: "about" */ './pages/Login/checkloginInformation/checkloginInformation.vue')
    },


    // 门诊首页
    {
      path: '/qutpatientHomePage',
      name: 'qutpatientHomePage',
      component: () => import(/* webpackChunkName: "about" */ './pages/OutpatientDepartment/qutpatientHomePage/qutpatientHomePage.vue')
    },
    // 完善个人信息
    {
      path: '/perfectingPersonalInformation',
      name: 'perfectingPersonalInformation',
      component: () => import(/* webpackChunkName: "about" */ './pages/OutpatientDepartment/putOnRecord/perfectingPersonalInformation/perfectingPersonalInformation.vue'),
      meta:{
        login:true
      }
    },
    // 核对个人信息
    {
      path: '/checkPersonalInformation',
      name: 'checkPersonalInformation',
      component: () => import(/* webpackChunkName: "about" */ './pages/OutpatientDepartment/putOnRecord/checkPersonalInformation/checkPersonalInformation.vue'),
      meta:{
        login:true
      }
    },
    // 挂号须知
    {
      path: '/noticeOfRegistration',
      name: 'noticeOfRegistration',
      component: () => import(/* webpackChunkName: "about" */ './pages/OutpatientDepartment/Register/noticeOfRegistration/noticeOfRegistration.vue'),
      meta:{
        login:true
      }
    },
    // 选择科室
    {
      path: '/selectDepartments',
      name: 'selectDepartments',
      component: () => import(/* webpackChunkName: "about" */ './pages/OutpatientDepartment/Register/selectDepartments/selectDepartments.vue'),
      meta:{
        login:true
      }
    },
    // 选择具体科室
    {
      path: '/selectionOfSpecificDepartments',
      name: 'selectionOfSpecificDepartments',
      component: () => import(/* webpackChunkName: "about" */ './pages/OutpatientDepartment/Register/selectionOfSpecificDepartments/selectionOfSpecificDepartments.vue'),
      meta:{
        login:true
      }
    },
    // 选择医生
    {
      path: '/chooseDoctor',
      name: 'chooseDoctor',
      component: () => import(/* webpackChunkName: "about" */ './pages/OutpatientDepartment/Register/chooseDoctor/chooseDoctor.vue'),
      meta:{
        login:true
      }
    },
    // 选择时间
    {
      path: '/chooseTime',
      name: 'chooseTime',
      component: () => import(/* webpackChunkName: "about" */ './pages/OutpatientDepartment/Register/chooseTime/chooseTime.vue'),
      meta:{
        login:true
      }
    },
    // 挂号信息
    {
      path: '/registrationInformation',
      name: 'registrationInformation',
      component: () => import(/* webpackChunkName: "about" */ './pages/OutpatientDepartment/Register/registrationInformation/registrationInformation.vue'),
      meta:{
        login:true
      }
    },

    // 就诊报到列表
    {
      path: '/reportToTheDoctorList',
      name: 'reportToTheDoctorList',
      component: () => import(/* webpackChunkName: "about" */ './pages/OutpatientDepartment/reportToTheDoctor/reportToTheDoctorList/reportToTheDoctorList.vue'),
      meta:{
        login:true
      }
    },
    // 挂号信息
    {
      path: '/checkRegistrationInformation/:type',
      name: 'checkRegistrationInformation',
      component: () => import(/* webpackChunkName: "about" */ './pages/OutpatientDepartment/reportToTheDoctor/checkRegistrationInformation/checkRegistrationInformation.vue'),
      meta:{
        login:true
      }
    },

    // 待缴费列表
    {
      path: '/listOfPendingCharges',
      name: 'listOfPendingCharges',
      component: () => import(/* webpackChunkName: "about" */ './pages/OutpatientDepartment/SelfServicePayment/listOfPendingCharges/listOfPendingCharges.vue'),
      meta:{
        login:true
      }
    },
    // 缴费详情
    {
      path: '/chargeDetail',
      name: 'chargeDetail',
      component: () => import(/* webpackChunkName: "about" */ './pages/OutpatientDepartment/SelfServicePayment/chargeDetail/chargeDetail.vue'),
      meta:{
        login:true
      }
    },
    // 待报到列表
    {
      path: '/listOfChecked',
      name: 'listOfChecked',
      component: () => import(/* webpackChunkName: "about" */ './pages/OutpatientDepartment/takeTheMedicineToRegister/listOfChecked/listOfChecked.vue'),
      meta:{
        login:true
      }
    },
    //报道详情
    {
      path:'/reportDetail',
      name:'reportDetail',
      component: () => import(/* webpackChunkName: "about" */ './pages/OutpatientDepartment/takeTheMedicineToRegister/listOfChecked/reportDetail.vue'),
      meta:{
        login:true
      }
    },
    // 待检查列表
    {
      path: '/listToBeChecked',
      name: 'listToBeChecked',
      component: () => import(/* webpackChunkName: "about" */ './pages/OutpatientDepartment/inspect/listToBeChecked/listToBeChecked.vue'),
      meta:{
        login:true
      }
    },
    // 待检查列表--选择时间
    {
      path: '/checkChooseTime',
      name: 'checkChooseTime',
      component: () => import(/* webpackChunkName: "about" */ './pages/OutpatientDepartment/inspect/checkChooseTime/checkChooseTime.vue'),
      meta:{
        login:true
      }
    },
    // 待检查列表--核对检查信息
    {
      path: '/checkInformation',
      name: 'checkInformation',
      component: () => import(/* webpackChunkName: "about" */ './pages/OutpatientDepartment/inspect/checkInformation/checkInformation.vue'),
      meta:{
        login:true
      }
    },
    // 待检打印报告列表
    {
      path: '/listOfReportsToBePrinted',
      name: 'listOfReportsToBePrinted',
      component: () => import(/* webpackChunkName: "about" */ './pages/OutpatientDepartment/Printing/InspectionReport/listOfReportsToBePrinted/listOfReportsToBePrinted.vue'),
      meta:{
        login:true
      }
    },
    // 核对报告打印信息
    {
      path: '/checkReportPrintInformation',
      name: 'checkReportPrintInformation',
      component: () => import(/* webpackChunkName: "about" */ './pages/OutpatientDepartment/Printing/InspectionReport/checkReportPrintInformation/checkReportPrintInformation.vue'),
      meta:{
        login:true
      }
    },
    // 待打印清单列表
    {
      path: '/listToBePrinted',
      name: 'listToBePrinted',
      component: () => import(/* webpackChunkName: "about" */ './pages/OutpatientDepartment/Printing/CostList/listToBePrinted/listToBePrinted.vue'),
      meta:{
        login:true
      }
    },
    // 待打印清单信息
    {
      path: '/listInformation',
      name: 'listInformation',
      component: () => import(/* webpackChunkName: "about" */ './pages/OutpatientDepartment/Printing/CostList/listInformation/listInformation.vue'),
      meta:{
        login:true
      }
    },


    // 住院服务首页
    {
      path: '/inpatientHomePage',
      name: 'inpatientHomePage',
      component: () => import(/* webpackChunkName: "about" */ './pages/Hospitalization/inpatientHomePage/inpatientHomePage.vue'),
      meta:{
        login:true
      }
    },
    // 入院登记列表
    {
      path: '/hospitalizationRegistrationList',
      name: 'hospitalizationRegistrationList',
      component: () => import(/* webpackChunkName: "about" */ './pages/Hospitalization/hospitalizationRegistrationList/hospitalizationRegistrationList.vue'),
      meta:{
        login:true
      }
    },
    // 核对住院信息
    {
      path: '/checkHospitalizationInformation',
      name: 'checkHospitalizationInformation',
      component: () => import(/* webpackChunkName: "about" */ './pages/Hospitalization/checkHospitalizationInformation/checkHospitalizationInformation.vue'),
      meta:{
        login:true
      }
    },
    // 出院列表
    {
      path: '/dischargeList',
      name: 'dischargeList',
      component: () => import(/* webpackChunkName: "about" */ './pages/Hospitalization/dischargeList/dischargeList.vue'),
      meta:{
        login:true
      }
    },
    // 核对出院信息
    {
      path: '/checkDischargeInformation',
      name: 'checkDischargeInformation',
      component: () => import(/* webpackChunkName: "about" */ './pages/Hospitalization/checkDischargeInformation/checkDischargeInformation.vue'),
      meta:{
        login:true
      }
    },
    // 住院列表
    {
      path: '/hospitalizationList',
      name: 'hospitalizationList',
      component: () => import(/* webpackChunkName: "about" */ './pages/Hospitalization/hospitalizationList/hospitalizationList.vue'),
      meta:{
        login:true
      }
    },


    // 选择支付方式
    {
      path: '/choosePayType',
      name: 'choosePayType',
      component: () => import(/* webpackChunkName: "about" */ './pages/pay/choosePayType/choosePayType.vue'),
      meta:{
        login:true
      }
    },
    // 支付方式
    {
      path: '/payType/:type',
      name: 'payType',
      component: () => import(/* webpackChunkName: "about" */ './pages/pay/payType/payType.vue'),
      meta:{
        login:true
      }
    },
    // 刷脸支付——身份验证
    {
      path: '/identityVerification',
      name: 'identityVerification',
      component: () => import(/* webpackChunkName: "about" */ './pages/pay/BrushPayment/identityVerification/identityVerification.vue'),
      meta:{
        login:true
      }
    },
    // 充值查询
    {
      path: '/rechargeQuery',
      name: 'rechargeQuery',
      component: () => import(/* webpackChunkName: "about" */ './pages/OutpatientDepartment/rechargeQuery/rechargeQuery.vue'),
      meta:{
        login:true
      }
    },
    // 选择充值金额
    {
      path: '/rechargeChoose',
      name: 'rechargeChoose',
      component: () => import(/* webpackChunkName: "about" */ './pages/OutpatientDepartment/rechargeQuery/rechargeChoose.vue'),
      meta:{
        login:true
      }
    },
  ]
})
